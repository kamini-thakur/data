<?php

$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('tmp/product_delete.txt', 'w');
fwrite($fh, $data);


?>