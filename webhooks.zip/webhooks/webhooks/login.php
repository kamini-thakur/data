

<?php


$Insta_redirect_uri=urlencode("https://esoftappslive.com/kamini/login.php");

$redirect_url='https://api.instagram.com/oauth/authorize/?client_id=002fd622c1c544ac84efa3935cb62795&redirect_uri='.$Insta_redirect_uri.'&response_type=code';
if(isset($_GET['code']))
{
	$code=$_GET['code'];
	echo $code; 

/*=============posting data with curl=============*/
 
$post_data=array('client_id'=>'002fd622c1c544ac84efa3935cb62795','client_secret'=>'f90262d27df64ad681dfe7a192176385',
	'grant_type'=>'authorization_code','redirect_uri'=>'https://esoftappslive.com/kamini/login.php','code'=>$code);

$url="https://api.instagram.com/oauth/access_token";
$handle=curl_init($url);

curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);    
$response=curl_exec($handle);
var_dump($response);
curl_error($handle);
curl_close($handle);
}
else
{
	header('location:'.$redirect_url);
}
/*
$filename='tmp/userdata'.date("F")."-".date("d").'.csv';
$filename= fopen($filename, "w+") or die("Unable to open file!");
$header = array("username","bio","website","profile_picture","full_name","id");
fwrite($filename , implode(",",$header)."\n");
fclose($filename);
*/

/*
session_start();
if(!empty($_SESSION['userdetails']))
{
	//header('Location:');
}

require 'instagram_config.php';

$loginurl=$instagram->getLoginUrl();
echo "<a href="$loginurl">sign in with instagram</a>";

*/
?>