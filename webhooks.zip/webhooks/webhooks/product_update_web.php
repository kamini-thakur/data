<?php


$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('tmp/product_update.txt', 'w');
fwrite($fh, $data);

fwrite($fh,$array->id);
fwrite($fh,$array->title);
foreach($array->images as $key=>$val)
		{
			$src=$val->src;
			
			
			fwrite($fh,$src);
			
		}


?>