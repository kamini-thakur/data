<?php

// $filename='tmp/order'.date("F")."-".date("d").'.csv';
// //chmod($filename, 0777);  
// $filename1 = fopen($filename, "w+") or die("Unable to open file!");
// $header = array("id","Email","total_price","order_number");
// fwrite($filename1 , implode(",",$header)."\n");

$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);


$fh =fopen('a.txt', 'a');
//fwrite($fh, $data);

 fwrite($fh,$array->email);
 fwrite($fh,$array->id);
 fwrite($fh,$array->price);
 //$temp_line_items = var_export($array->line_items, true);
 //fwrite($fh,"esf".$temp_line_items);

//$rows=array();
// foreach($array as $value)
// {
 		
	// $id=($array->id);
	// $email=($array->email);
	// $total_price=($array->total_price);
	// $order_number=($array->order_number);

	// $rows[]=$id;
	// $rows[]=$email;
	// $rows[]=$total_price;
	// $rows[]=$order_number;

	
	// 	foreach($array->line_items as $key=>$val)
	// 	{
	// 		$title=$val->title;
	// 		//$rows[]=$title;
	// 		fwrite($fh,$title);
	// 	}

		
	// 	$first_name=($array->billing_address->first_name);
	// 	$last_name=($array->billing_address->last_name);
	// 	$zip=($array->billing_address->zip);
	// 	$city=($array->billing_address->city);

	// 	$rows[]=$first_name;
	// 	$rows[]=$last_name;
	// 	$rows[]=$zip;
	// 	$rows[]=$city;
	
	// 	fwrite($fh,implode("",$rows)."\n");
	// 	//dump_data($rows,$fh);
	// 	$rows=array();

//}

// function dump_data($rows,$fh)
//  {
//     fwrite($fh,implode("",$rows)."\n");
//  }








// $filename='tmp/order'.date("F")."-".date("d").'.csv';
// //chmod($filename, 0777);  
// $filename1 = fopen($filename, "w+") or die("Unable to open file!");
// $header = array("Email","total_price","order_number");
// fwrite($filename1 , implode(",",$header)."\n");




?>