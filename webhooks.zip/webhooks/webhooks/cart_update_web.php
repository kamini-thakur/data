<?php

$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('tmp/cart_update.txt', 'w');
fwrite($fh, $data);

foreach($array->line_items as $key=>$val)
		{
			$title=$val->title;
			$price=$val->price;
			//$rows[]=$title;
			fwrite($fh,$title);
			fwrite($fh,$price);
		}
?>