<?php


$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);


$fh =fopen('orderCreate.txt', 'w');
fwrite($fh, $data);


 //fwrite($fh,$array->email);
 //fwrite($fh,$array->id);
 //fwrite($fh,$array->price);
 //$temp_line_items = var_export($array->line_items, true);
 //fwrite($fh,"esf".$temp_line_items);

$count=0;
foreach($array->line_items as $key=>$val)
{
	$title=$val->title;
	if($title == 'Engraving')
	{
		$id=$val->id;
		$count++;
	}
}

fwrite($fh, $id);
fwrite($fh, $count);
		


?>