<?php


// settings => notifications

$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('tmp/product.txt', 'w');
fwrite($fh, $data);

$id=$array->id;
$title=$array->title;
fwrite($fh,$id);
fwrite($fh,$title);
foreach($array->variants as $key=>$val)
		{
			$price=$val->price;
			//$rows[]=$title;
			$inventory_quantity=$val->inventory_quantity;
			fwrite($fh,$price);
			fwrite($fh,$inventory_quantity);
		}


?>