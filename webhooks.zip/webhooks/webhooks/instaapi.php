
<?php

$filename='tmp/userdata'.date("F")."-".date("d").'.csv';
$filename= fopen($filename, "w+") or die("Unable to open file!");
$header = array("username","bio","website","profile_picture","full_name","id");
fwrite($filename , implode(",",$header)."\n");


$Insta_redirect_uri=urlencode("https://esoftappslive.com/kamini/instaapi.php");

$redirect_url='https://api.instagram.com/oauth/authorize/?client_id=002fd622c1c544ac84efa3935cb62795&redirect_uri='.$Insta_redirect_uri.'&response_type=code';


if(isset($_GET['code']))
{
	$code=$_GET['code'];
	//echo $code; 
	//die;

/*=============posting data with curl=============*/

$post_data=array('client_id'=>'002fd622c1c544ac84efa3935cb62795','client_secret'=>'f90262d27df64ad681dfe7a192176385',
	'grant_type'=>'authorization_code','redirect_uri'=>'https://esoftappslive.com/kamini/instaapi.php','code'=>$code);

$url="https://api.instagram.com/oauth/access_token";
$handle=curl_init($url);

curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);    
$response=curl_exec($handle);
var_dump($response);
curl_error($handle);
curl_close($handle);
$row=array();
//print_r($user);

   $username=($response->user->username);
   $bio=($response->user->bio);
	$website=($response->user->website);
	$profile_picture=($response->user->profile_picture);
	$full_name=($response->user->full_name);
	$id=($response->user->id);
	$row[]=$username;
	$row[]=$bio;
	$row[]=$website;
	$row[]=$profile_picture;
	$row[]=$full_name;
	$row[]=$id;
	
	//fwrite($filename , implode(",",$row)."\n");


fclose($filename);

/*===============closing cURL resource==================*/

/*=============Get the most recent media===============*/
	/*
	function get_media($media_url)
	{
		$handle1=curl_init($media_url);
		curl_setopt($handle1, CURLOPT_RETURNTRANSFER, true);
		$result=curl_exec($handle1);
		curl_close($handle1);
		return $result;
	}
	$media_url="https://api.instagram.com/v1/users/2203196541/media/recent/?access_token=2203196541.002fd62.b97ed4d337c34d5eb6b7122b5860196d";
	//$media_url="https://api.instagram.com/v1/users/self/media/recent/?access_token=2203196541.002fd62.b97ed4d337c34d5eb6b7122b5860196d";
	$total_result=get_media($media_url);
	$decoded_results=json_decode($total_result,true);
	//print_r($decoded_results);
	foreach($decoded_results['data'] as $item)
	{
	     $image_link = $item['images']['thumbnail']['url'];
	    // echo $image_link;
	     echo '<img src="'.$image_link.'" />';
	}
	*/
/*==============================================*/

}
else
{
	header('location:'.$redirect_url);
}






//?code=9bd1ffb21e7646e6a9177c73a426f894
//"access_token": "2203196541.002fd62.b97ed4d337c34d5eb6b7122b5860196d"
?>

