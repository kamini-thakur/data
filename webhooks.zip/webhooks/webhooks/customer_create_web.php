<?php
require_once("class.phpmailer.php");
include("class.smtp.php");


$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('tmp/customer.txt', 'w');
fwrite($fh, $data);


$fname=$array->first_name;
$lname=$array->last_name;

 	$mail = new PHPMailer();
    $body             = "Hello, a new customer $fname $lname registered with your shop";

    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->Host       = "smtp.gmail.com"; // SMTP server
    $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                               // 1 = errors and messages
                                               // 2 = messages only
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->Host       = "smtp.gmail.com"; // sets the SMTP server
    $mail->Port       = 587;                    // set the SMTP port for the GMAIL server
    $mail->Username   = "testmail.esfera@gmail.com"; // SMTP account username
    $mail->Password   = "esfera123";        // SMTP account password

    $mail->Subject    = "New Customer";
    $mail->MsgHTML($body);

    //$mail->AddAddress("amardeep_singh@esferasoft.com");
    $mail->AddAddress("kamini_thakur@esferasoft.com");
    //$mail->AddAttachment($filename);
    
    if(!$mail->Send()) {
     echo "Mailer Error: " . $mail->ErrorInfo;
    } else 
    {
      echo "Message sent!";
    } 

?>