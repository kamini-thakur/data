<?php

define('SHOPIFY_APP_SECRET', '94ce18616299156fa2b75eae7510bf62');

function verify_webhook($data, $hmac_header)
{
  $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_APP_SECRET, true));
  return ($hmac_header == $calculated_hmac);
}

$fh =fopen('tmp/fulfillment_create.txt', 'w');
$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
fwrite($fh, $hmac_header);
$data = file_get_contents('php://input');
$verified = verify_webhook($data, $hmac_header);
fwrite($fh,'Webhook verified: '.var_export($verified, true));

//$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);


//fwrite($fh, $tempVar);

fwrite($fh,$array->tracking_number);
fwrite($fh,$array->tracking_url);
$tracking_number=$array->tracking_number;
$tracking_url=$array->tracking_url;
		

?>